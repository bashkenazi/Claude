"""Quarterly Review engine: builds the QR workbook from a per-company spec (see references/example_spec_twlo.py)."""
import json, sys, datetime
from zoneinfo import ZoneInfo
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.comments import Comment

import math, os

# usage: python3 qr_build.py <spec.py> <live|values> <out.xlsx> [print_scale_pct]
SPEC = sys.argv[1]
MODE = sys.argv[2]            # "live" = VAData formulas; "values" = captured numbers (for recalc + PDF)
OUT = sys.argv[3]
SCALE = int(sys.argv[4]) if len(sys.argv) > 4 else 50
exec(compile(open(SPEC).read(), SPEC, "exec"), globals())   # defines META, ledgers, build_body()
D = json.load(open(os.path.join(os.path.dirname(os.path.abspath(SPEC)), META["va_json"])))
NOW = datetime.datetime.now(ZoneInfo("America/New_York")).strftime("%Y-%m-%d %H:%M ET")

TICKER = META["va_ticker"]
F = "Arial"
BLUE = "0000FF"
FMT_D = '#,##0;(#,##0);"-"'
FMT_P = '0.0%;(0.0%);"-"'
FMT_E = '0.00;(0.00);"-"'
GREY = PatternFill("solid", fgColor="F2F2F2")
HDR = PatternFill("solid", fgColor="1F3864")
SEC = PatternFill("solid", fgColor="D9E1F2")
YEL = PatternFill("solid", fgColor="FFFF00")
thin = Side(style="thin", color="808080")

# ---------- columns ----------
def qlist(y0, q0, n):
    out, y, q = [], y0, q0
    for _ in range(n):
        out.append((y, q)); q += 1
        if q == 5: q, y = 1, y + 1
    return out
COLS = []  # dict(col, kind, y, q, label, vakey, dkey, hidden, est)
LY, LQ = META["last_actual"]            # last reported quarter (fiscal year, quarter)
y0, q0 = LY, LQ
for _ in range(15):                     # 12 visible trailing qtrs + 4 hidden y/y helper qtrs
    q0 -= 1
    if q0 == 0: q0, y0 = 4, y0 - 1
LFY = LY if LQ == 4 else LY - 1         # last fully reported fiscal year
c = 3  # C
for i, (y, q) in enumerate(qlist(y0, q0, 24)):
    est = (y, q) > (LY, LQ)
    COLS.append(dict(col=c, kind="q", y=y, q=q, hidden=i < 4, est=est,
                     label=f"{q}Q{str(y)[2:]}{'E' if est else 'A'}", vakey=f"{q}Q-{str(y)[2:]}", dkey=f"{y} Q{q}"))
    c += 1
for i, y in enumerate(range(LFY - 3, LFY + 4)):
    est = y > LFY
    COLS.append(dict(col=c, kind="fy", y=y, q=None, hidden=i == 0, est=est,
                     label=f"FY{str(y)[2:]}{'E' if est else 'A'}", vakey=f"FY-{str(y)[2:]}", dkey=str(y)))
    c += 1
LASTDATA = c - 1
GAP = c; SLAB = c + 1; SC = [c + 2, c + 3, c + 4]
QCOLS = [x for x in COLS if x["kind"] == "q"]
FYCOLS = [x for x in COLS if x["kind"] == "fy"]
BYKEY = {x["dkey"]: x for x in COLS}
FIRST_VIS_Q = next(x for x in QCOLS if not x["hidden"])["col"]

def prev(cx, lag):
    """column of same-kind period `lag` back (4 qtrs back for y/y, 1 back for q/q / FY y/y)."""
    grp = QCOLS if cx["kind"] == "q" else FYCOLS
    i = grp.index(cx) - lag
    return grp[i]["col"] if i >= 0 else None

wb = Workbook()
ws = wb.active; ws.title = "Quarterly Review"
ref = wb.create_sheet("Ref")
ws.sheet_view.showGridLines = False
ws.sheet_view.zoomScale = 70

def font(**k):
    base = dict(name=F, size=7)
    base.update(k)
    return Font(**base)

# ---------- Ref sheet ----------
ref["A1"] = f"QR reference — {META['short']}"; ref["A1"].font = Font(name=F, bold=True)
ref["A2"] = "VA ticker key"; ref["B2"] = TICKER; ref["B2"].font = Font(name=F, color=BLUE)
ref["A3"] = "VA $ unit divisor (1 if VA returns $mm; 1000000 if raw $)"; ref["B3"] = 1 if MODE == "live" else 1
ref["B3"].font = Font(name=F, color=BLUE); ref["B3"].fill = YEL
ref["A4"] = "Fiscal calendar"; ref["B4"] = META["fiscal_note"]
ref["A5"] = "Run"; ref["B5"] = f"Generated {NOW}; mode={MODE}; {META['source_note']}"
ref["A7"] = "Period"; ref["B7"] = "VA period key"; ref["C7"] = "Earnings date"
EARN = META.get("earnings_dates", {})
for i, cx in enumerate(COLS):
    r = 8 + i
    ref.cell(r, 1, cx["label"]); ref.cell(r, 2, cx["vakey"])
    if MODE == "live":
        ref.cell(r, 3, f'=_xll.VADetail("EarningsDate",$B$2,B{r})')
    else:
        ref.cell(r, 3, EARN.get(cx["dkey"], ""))
LI0 = 8 + len(COLS) + 2
ref.cell(LI0, 1, "VA line items used (verbatim third arg of VAData)").font = Font(name=F, bold=True)
ref.column_dimensions["A"].width = 58; ref.column_dimensions["B"].width = 40; ref.column_dimensions["C"].width = 14
used_items = []

# ---------- main grid helpers ----------
ROWS = {}
ROW_ITEM = {}
r = 1
def put_label(rr, text, bold=False, italic=False, indent=0, size=7, color=None):
    cl = ws.cell(rr, 2, text)
    cl.font = font(bold=bold, italic=italic, size=size, color=color)
    cl.alignment = Alignment(horizontal="left", indent=indent * 2)   # 2 indent units per level so hierarchy reads at 50% zoom

def va_value(item, cx, scale):
    rec = D[item][("QTR" if cx["kind"] == "q" else "FY")].get(cx["dkey"])
    if not rec: return None
    v = rec["a"] if (rec["a"] is not None and not cx["est"]) else rec["c"]
    if v is None: return None
    return v / 1e6 if scale else v

def va_row(key, label, item, fmt=FMT_D, scale=True, bold=False, indent=0, src_note=None):
    global r
    ROWS[key] = r
    ROW_ITEM[key] = item
    put_label(r, label, bold=bold, indent=indent)
    used_items.append(item)
    for cx in COLS:
        cell = ws.cell(r, cx["col"])
        if MODE == "live":
            f = f'_xll.VisibleAlpha.UDF.VAData(Ref!$B$2,"{cx["vakey"]}","{item}")'
            cell.value = f"=IFERROR({f}/Ref!$B$3,\"\")" if scale else f"=IFERROR({f},\"\")"
        else:
            v = va_value(item, cx, scale)
            cell.value = v if v is not None else None
        cell.number_format = fmt
        cell.font = font(bold=bold)
    r += 1

def calc_row(key, label, fn, fmt=FMT_P, italic=True, indent=1, bold=False, kinds=("q", "fy")):
    global r
    ROWS[key] = r
    put_label(r, label, italic=italic, indent=indent, bold=bold)
    for cx in COLS:
        if cx["kind"] not in kinds: continue
        f = fn(cx)
        if f is None: continue
        cell = ws.cell(r, cx["col"], f)
        cell.number_format = fmt
        cell.font = font(italic=italic, bold=bold)
    r += 1

def yy(src):
    def fn(cx):
        p = prev(cx, 4 if cx["kind"] == "q" else 1)
        if p is None: return None
        a, b = f"{L(cx['col'])}{ROWS[src]}", f"{L(p)}{ROWS[src]}"
        return f'=IFERROR(IF(N({b})<=0,"",{a}/{b}-1),"")'   # blank when prior period is zero or a loss
    return fn
def qq(src):
    def fn(cx):
        p = prev(cx, 1)
        if p is None: return None
        a, b = f"{L(cx['col'])}{ROWS[src]}", f"{L(p)}{ROWS[src]}"
        return f'=IFERROR(IF(N({b})<=0,"",{a}/{b}-1),"")'
    return fn
def ratio(num, den):
    def fn(cx):
        a, b = f"{L(cx['col'])}{ROWS[num]}", f"{L(cx['col'])}{ROWS[den]}"
        return f'=IFERROR(IF(N({b})=0,"",{a}/{b}),"")'
    return fn

def growth_block(key, label, item, bold=False, indent=0, mix=True, qoq=True):
    va_row(key, label, item, bold=bold, indent=indent)
    calc_row(key + "_yy", "y/y", yy(key), indent=indent + 1)
    if qoq: calc_row(key + "_qq", "q/q", qq(key), kinds=("q",), indent=indent + 1)
    if mix and key != "rev": calc_row(key + "_mix", "% of total rev", ratio(key, "rev"), indent=indent + 1)

def text_row(tag, text, note=None):
    global r
    put_label(r, tag, italic=True, indent=1, size=6, color="595959")
    cl = ws.cell(r, FIRST_VIS_Q, text)
    cl.font = font(italic=True, size=6, color=BLUE)
    cl.alignment = Alignment(wrap_text=False)
    if note: cl.comment = Comment(note, "QR")
    r += 1

QW = 9.0  # quarter / FY column width

def percol_row(tag, label, data, note=None):
    """One shorthand item per column, placed in the column of the call/quarter it came from; wrapped."""
    global r
    put_label(r, f"{tag} {label}", italic=True, indent=1, size=6, color="595959")
    ws.cell(r, 2).alignment = Alignment(horizontal="left", indent=2, vertical="top")
    lines = 1
    for k, t in data.items():
        cx = BYKEY.get(k)
        if not cx or cx["hidden"]: continue
        cl = ws.cell(r, cx["col"], t)
        cl.font = font(italic=True, size=5.5, color=BLUE)
        cl.alignment = Alignment(wrap_text=True, vertical="top", horizontal="left")
        lines = max(lines, math.ceil(len(t) / (QW * 1.55)))
    ws.row_dimensions[r].height = max(9.5, 7.2 * lines + 1)
    if note: ws.cell(r, 2).comment = Comment(note, "QR")
    r += 1

def hard_row(key, label, data, fmt=FMT_P, indent=1, bold=False, note=None):
    """Numeric transcript-sourced values (blue hardcodes) in the quarter they were disclosed."""
    global r
    ROWS[key] = r
    put_label(r, label, indent=indent, italic=True, bold=bold)
    for k, v in data.items():
        cx = BYKEY.get(k)
        if not cx: continue
        cl = ws.cell(r, cx["col"], v); cl.font = font(color=BLUE, bold=bold); cl.number_format = fmt
    if note: ws.cell(r, 2).comment = Comment(note, "QR")
    r += 1

def section(title, period_labels=False):
    global r
    for col in range(2, LASTDATA + 1):
        ws.cell(r, col).fill = SEC
    put_label(r, title, bold=True)
    if period_labels:
        for cx in COLS:
            cl = ws.cell(r, cx["col"], cx["label"])
            cl.font = font(bold=True); cl.alignment = Alignment(horizontal="center")
    r += 1

# ---------- header ----------
ws.cell(1, 2, f"{META['title']} — Quarterly Review").font = Font(name=F, size=12, bold=True)
ws.cell(2, 2, f"$mm except per share | {META['fiscal_note']} | A = actual, E = Visible Alpha consensus | Gd = guidance, Discl = disclosure (Quartr transcripts)").font = font(italic=True)
r = 4
for cx in COLS:
    cl = ws.cell(r, cx["col"], cx["label"])
    cl.font = font(bold=True, color="FFFFFF"); cl.fill = HDR; cl.alignment = Alignment(horizontal="center")
put_label(r, "Period", bold=True, color="FFFFFF"); ws.cell(r, 2).fill = HDR
r = 5
for cx in COLS:
    cl = ws.cell(r, cx["col"], f'=IF(Ref!C{8 + COLS.index(cx)}="","",Ref!C{8 + COLS.index(cx)})')
    cl.font = font(size=6, color="008000"); cl.alignment = Alignment(horizontal="center")
put_label(r, "Earnings date", italic=True, size=6)
r = 6

# ---------- company-specific rows (defined in the spec) ----------
PB_ROW = None
build_body()          # spec calls the row helpers above; must set FOOT (and PB_ROW for the page break)

# ---------- formatting ----------
ws.column_dimensions["A"].width = 1
ws.column_dimensions["B"].width = 36
for cx in COLS:
    ws.column_dimensions[L(cx["col"])].width = QW
    if cx["hidden"]: ws.column_dimensions[L(cx["col"])].hidden = True
    if cx["est"]:
        for rr in range(6, FOOT - 1):
            cl = ws.cell(rr, cx["col"])
            if cl.fill.fgColor.rgb in (None, "00000000"): cl.fill = GREY
# vertical lines: thin at each fiscal-year start (1Q columns, each FY column); heavy at consensus start and FY block start
med = Side(style="medium", color="000000")
first_est_q = next(x for x in QCOLS if x["est"])["col"]
first_fy = next(x for x in FYCOLS if not x["hidden"])["col"]
for cx in COLS:
    if cx["hidden"]: continue
    if cx["col"] in (first_est_q, first_fy): side = med
    elif (cx["kind"] == "q" and cx["q"] == 1) or cx["kind"] == "fy": side = thin
    else: continue
    for rr in range(4, FOOT - 1):
        ws.cell(rr, cx["col"]).border = Border(left=side)
# right edge of the grid
for rr in range(4, FOOT - 1):
    ws.cell(rr, LASTDATA).border = Border(left=ws.cell(rr, LASTDATA).border.left, right=thin)
ws.freeze_panes = ws.cell(6, FIRST_VIS_Q)

# ---------- Sensitization (off-print) ----------
ws.column_dimensions[L(GAP)].width = 2
ws.column_dimensions[L(SLAB)].width = 30
for cc in SC: ws.column_dimensions[L(cc)].width = 8
s0 = 4
ws.cell(s0 - 2, SLAB, "Earnings Power — inputs in blue").font = Font(name=F, size=9, bold=True)
fys = [str(LFY + 1), str(LFY + 2), str(LFY + 3)]
for i, k in enumerate(fys):
    cl = ws.cell(s0, SC[i], f"FY{k[2:]}E"); cl.font = font(bold=True, color="FFFFFF"); cl.fill = HDR
ws.cell(s0, SLAB, "Sensitized").font = font(bold=True, color="FFFFFF"); ws.cell(s0, SLAB).fill = HDR
fyc = lambda k: L(BYKEY[k]["col"])
SEGS = META["sens_segments"]          # [(row_key, label)] - reported segments; must be rows built in build_body
def seedval(key, k):
    if key in ROW_ITEM:
        return va_value(ROW_ITEM[key], BYKEY[k], key != "eps")
    raise KeyError(key)
S = {}
labels = [("g_" + k, f"{lab} rev growth") for k, lab in SEGS] + [("elim", "Other / elims ($mm)")] + \
         [(k, f"{lab} rev") for k, lab in SEGS] + \
         [("rev", "Total revenue"), ("rev_yy", "  y/y"), ("vs_c", "  vs consensus"), ("gm", "Gross margin"), ("gp", "Gross profit"),
          ("opx", "Opex % of rev"), ("oi", "Operating income"), ("om", "  Op margin"), ("conv", "OI → net income conversion"),
          ("shs", "Diluted shares (mm)"), ("eps", "EPS (non-GAAP)"), ("eps_vs", "  vs consensus EPS")]
for j, (k, lab) in enumerate(labels):
    S[k] = s0 + 1 + j
    ws.cell(S[k], SLAB, lab).font = font(bold=k in ("rev", "oi", "eps"))
for i, k in enumerate(fys):
    col = L(SC[i]); pk = str(int(k) - 1)
    prevc = (lambda key: f"{fyc(pk)}{ROWS[key]}") if i == 0 else (lambda key, pc=L(SC[i-1]): f"{pc}{S[key]}")
    rv, gp, oi, ep, sh = (seedval(x, k) for x in ("rev", "gp", "oi", "eps", "shs"))
    seeds = {"elim": rv - sum(seedval(sk, k) for sk, _ in SEGS), "gm": gp / rv, "opx": (gp - oi) / rv,
             "conv": ep * sh / oi, "shs": sh}
    for sk, _ in SEGS:
        seeds["g_" + sk] = seedval(sk, k) / seedval(sk, pk) - 1
    for key, v in seeds.items():
        cl = ws.cell(S[key], SC[i], round(v, 4) if key not in ("elim", "shs") else round(v, 1))
        cl.font = font(color=BLUE); cl.fill = YEL
        cl.number_format = FMT_D if key == "elim" else ('#,##0.0' if key == "shs" else FMT_P)
    F_ = {sk: f"={prevc(sk)}*(1+{col}{S['g_' + sk]})" for sk, _ in SEGS}
    F_.update({
        "rev": "=" + "+".join(f"{col}{S[sk]}" for sk, _ in SEGS) + f"+{col}{S['elim']}",
        "rev_yy": f"=IFERROR({col}{S['rev']}/{prevc('rev')}-1,\"\")",
        "vs_c": f"=IFERROR({col}{S['rev']}/{fyc(k)}{ROWS['rev']}-1,\"\")",
        "gp": f"={col}{S['rev']}*{col}{S['gm']}",
        "oi": f"={col}{S['gp']}-{col}{S['rev']}*{col}{S['opx']}",
        "om": f"=IFERROR({col}{S['oi']}/{col}{S['rev']},\"\")",
        "eps": f"=IFERROR({col}{S['oi']}*{col}{S['conv']}/{col}{S['shs']},\"\")",
        "eps_vs": f"=IFERROR({col}{S['eps']}/{fyc(k)}{ROWS['eps']}-1,\"\")",
    })
    for key, f in F_.items():
        cl = ws.cell(S[key], SC[i], f); cl.font = font(bold=key in ("rev", "oi", "eps"))
        cl.number_format = FMT_E if key == "eps" else (FMT_P if key in ("rev_yy", "vs_c", "om", "eps_vs") else FMT_D)
note_r = s0 + len(labels) + 2
ws.cell(note_r, SLAB, f"Seeds = VA consensus at build (growth vs prior FY; FY{str(LFY)[2:]}A base). Edit yellow cells.").font = font(italic=True, size=6)
ws.cell(note_r + 1, SLAB, "Conversion = cons EPS × shares ÷ cons OI (captures interest, tax).").font = font(italic=True, size=6)

# ---------- Ref line items ----------
for i, it in enumerate(dict.fromkeys(used_items)):
    ref.cell(LI0 + 1 + i, 1, it)
ref.sheet_state = "hidden"

# ---------- print setup ----------
ws.print_area = f"B1:{L(LASTDATA)}{FOOT}"
ws.page_setup.orientation = "landscape"
ws.page_setup.paperSize = ws.PAPERSIZE_LETTER
ws.page_setup.fitToWidth = 1
ws.page_setup.fitToHeight = 2
ws.print_title_rows = "4:5"
from openpyxl.worksheet.pagebreak import Break
if PB_ROW: ws.row_breaks.append(Break(id=PB_ROW))
ws.sheet_properties.pageSetUpPr.fitToPage = False
ws.page_setup.scale = SCALE
ws.print_options.horizontalCentered = True
ws.page_margins.left = ws.page_margins.right = 0.2
ws.page_margins.top = ws.page_margins.bottom = 0.25
for row in ws.iter_rows(min_row=6, max_row=FOOT):
    ws.row_dimensions[row[0].row].height = ws.row_dimensions[row[0].row].height or 9.5
wb.save(OUT)
print("rows", FOOT, "lastcol", L(LASTDATA), "sens", L(SC[0]), L(SC[-1]))
