---
name: quarterly-review
description: Quarterly Review (QR) builder for Bobby Ashkenazi (SRS Investment Management). Builds a landscape Excel Quarterly Review for any covered company with live Visible Alpha add-in formulas for every raw number, Excel calcs for y/y, q/q and % of total on every revenue segment, product line and geography, guidance and disclosure shorthand placed in the column of the quarter it was given, numeric rows for key management disclosures such as organic growth ex one-offs and net expansion, a quarterly and fiscal-year guidance-vs-actual block, an off-print earnings-power sensitization block, and a two-page PDF snapshot. Use whenever Bobby says create a quarterly review, quarterly review for a ticker, build the QR, run the QR, make me a QR, or asks for an updatable Excel summary of a company's segments, growth, margins, disclosures and guidance built on Visible Alpha formulas.
user-invocable: true
argument-hint: "<ticker>"
---

# Quarterly Review (QR) Builder

Build a single-company Quarterly Review: a working Excel (live VA add-in formulas, refreshable on Bobby's machine) plus a PDF snapshot. Bobby opens it and is current on growth drivers, every revenue segment and its y/y growth, margins, what management disclosed each quarter, and every piece of guidance, so he can read each item's progression across the columns before he talks to management.

Two files do the deterministic work:
- `scripts/qr_build.py` — the engine (columns, VA formulas, styling, guidance grid, sensitization, print setup).
- `references/example_spec_twlo.py` — a complete worked spec (TWLO, 3Q26). Each new company gets its own spec modeled on it: `META`, the transcript ledgers, and `build_body()` (the row layout).

Proven on TWLO (software; guides quarterly and FY revenue/OI) and INTC (semis; guides only quarterly revenue/GM/EPS, segment basis changes). The adaptations INTC needed are written into Steps 2, 4 and 5 below.

## Step 0 — Feedback page

Read the Anthropic Feedback page (32da883333de804abe78fa41e399a444): Global Feedback plus any quarterly-review section, and apply standing rules. If the page is missing or blank, apply the defaults: YYYY-MM-DD dates, bold key items, footer `Generated YYYY-MM-DD HH:MM ET` (footer only).

## Step 1 — Resolve the company in Visible Alpha

Confirm (a) the exact VA ticker key the add-in uses (e.g. `TWLO_US`, `INTC`, `COHR_US`; read it, never guess; formats differ by company), (b) the fiscal-year convention (quarter labels follow the fiscal calendar; COHR is June FYE), (c) the line-item tree.

| Environment | Route |
|---|---|
| Chrome available (desktop) | Claude in Chrome. Prefer Office PC (01e01e92), else any connected browser without prompting. If VA is not logged in, stop and tell Bobby. |
| No browser (cloud session) | SRS MCP `va_company_data`: `resolve` (ticker key), then `list_kpis` (QTR, plus keyword searches for gross profit, income from operations, operating income, EPS, shares, FCF, capex, organic, customers). The KPI names it returns are the VA display names used as VAData's third argument. |

## Step 2 — Capture the VA line items and values

Record the exact display name of every line item. Capture whatever the company and VA carry; skip what they don't:
- Total revenue, organic revenue (if VA carries it)
- **Every revenue segment**: reported segments, product lines, geography, customer cohorts (top-N customers, new vs existing), and sub-drivers (bits, ASP, units)
- Gross profit (total and by segment), operating income (total, by segment, corporate, eliminations), GAAP GP/OI as memo lines
- EPS (diluted, operating), diluted shares, FCF (and adjusted FCF if the company uses it)

Pull values for 16 trailing quarters (12 shown plus 4 hidden helpers so the first visible quarter has a y/y base), 8 forward quarters, and FY from LFY−3 to LFY+3, where LFY is the last fully reported fiscal year. In a cloud session, pull with `kpi_data` (QTR and FY, min_year = first helper quarter's year) through a background subagent, and write a JSON file next to the spec shaped like this:
`{"<KPI name>": {"kpi_id": N, "unit": "...", "QTR": {"2023 Q1": {"a": reported, "c": consensus, "n": brokers}}, "FY": {"2023": {...}}}}`
Raw units ($); the engine divides by 1e6. Ask the subagent to report the latest-quarter values, the segment sums vs total, and any series breaks.

Sanity-check before building, and act on each finding:

| Check | If it fails |
|---|---|
| Segments sum to total; sub-lines sum to their segment | Add a recon row; if sub-lines don't tie, keep them but comment them as VA-modelled |
| A series changes basis (segment redefined, old basis in the helper quarters) | Null the old-basis periods in the JSON for the values copy, comment the row, and tell Bobby the live file will still pull them |
| A series breaks (step change, stalls, repeats the same value, exceeds total) | Show the level only (no growth rows) next to a `hard_row` of management's figures, or drop it |
| A definition changed (customer counts) | Drop it |
| VA-derived because the company stopped disclosing, or discloses only annually | Keep it; say so in the section title or a cell comment |

## Step 3 — Transcript mining (Quartr, last 3 years)

`srs_documents` (quartr, company_transcript, num_periods=12), then `srs_documents_analyze` over every earnings call, plus the investor/analyst day and the latest 2-3 conferences. Ask for exact numbers on:
1. **Guidance given on each call**: next-quarter revenue $ range, reported and organic y/y range, GM, OI/EPS range; FY revenue growth, GM, OI, opex, capex, FCF; each change vs the prior guide (↑/↓/mnt); segment direction for next quarter; multi-year/LT targets.
2. **Disclosures for the quarter reported**: segment/product growth rates and margins, organic growth, net expansion, units/ASP, customers, mix, supply, one-offs (pass-through fees, impairments, divestitures, government funding, equity raises, M&A).
3. **Growth and margin drivers** management cites.

Load the results into the spec's ledgers, keyed by the call quarter `"YYYY Qn"` (see the example spec):

| Ledger | Holds | Lands as |
|---|---|---|
| `Q_GUIDE[period]` | quarterly guide FOR that period (tuple of whatever the company guides) | guidance grid |
| `GD_*[call qtr]` | FY / segment / GM / OI / opex / capex / FCF guidance given on that call | `Gd:` per-column rows |
| `FY_GD_*[fy]`, `FY_GD_SRC[fy]` | latest FY guide or target and the call it came from | FY columns of the guidance grid |
| numeric dicts (e.g. `MSG_ORG_MGMT`, `DBNE`, `DCAI_YY_MGMT`) | quantified disclosures | `hard_row` number rows |
| `D_*[reported qtr]` | qualitative disclosures | `Discl:` per-column rows |
| `COMMENTS` | themes (AI, roadmap, capital/balance sheet, M&A) | comments section |

Write cell text in the shorthand of `references/shorthand.md`. A long ledger can live in its own file next to the spec and be loaded at the top of the spec with `exec(open(<path beside SPEC>).read(), globals())`.

## Step 4 — Build the workbook

Read /mnt/skills/public/xlsx/SKILL.md first (blue inputs, black formulas, negatives in parens, zero formula errors). Then copy `references/example_spec_twlo.py` to `<ticker>_spec.py` beside the captured JSON and set `META`:
- `va_ticker`, `title`, `va_json`, `last_actual`
- `fiscal_note`, `source_note`, `earnings_dates`
- `sens_segments`: the segments the sensitization grows. Pick segments that, with the "Other / elims" input, sum to total revenue and have clean series. Leave broken or tiny series (and intersegment eliminations) inside "Other / elims" rather than growing them; e.g. for INTC, revenue = CCPG + DCAI + All other + (foundry external in Other / elims).

Then rewrite `build_body()` with this section order. Every section opens with `section(...)`.

1. **TOTAL REVENUE** — total revenue block (revenue, y/y, q/q); organic revenue and organic y/y (vs prior-year total) where it exists; any pass-through/one-off revenue as a calc row; `Gd:` FY guidance; `Discl:` total/corporate; recurring numeric disclosures as `hard_row`s (net expansion, AI share of revenue) with a calc ex-one-off row where management gives the one-off contribution.
2. **REPORTED SEGMENTS** — `growth_block` per segment (revenue, y/y, q/q, % of total), nested by the company's own hierarchy (a parent like Intel Products at level 0, its divisions at level 1, sub-lines and units/ASP at level 2), each followed by its own `Gd:`/`Discl:` per-column rows; then eliminations and a recon calc row.
3. **REVENUE BY PRODUCT** — same pattern per product line. Where management quantifies organic or one-off-adjusted growth for a line, add three `hard_row`s (mgmt reported y/y, one-off contribution in pts, mgmt organic y/y) plus a calc row that strips the one-off from every column, consensus included. Put a cell comment on the calc row saying how close it tracks management's figures. Then a product recon row.
4. **REVENUE BY GEOGRAPHY / CUSTOMER** — `growth_block` per region and customer cohort.
5. **GROSS PROFIT** — GP, y/y, GM; segment GP and GM only if they tie to the segment totals; GAAP GM memo; `Gd:`/`Discl:` rows. Set `PB_ROW = r - 1` just before this section so page 2 starts here.
6. **OPERATING INCOME** — OI, y/y, OM; segment OI/OM, corporate, eliminations, GAAP memo; `Gd:`/`Discl:` rows.
7. **EPS / SHARES / CASH FLOW** — EPS and y/y, diluted shares and y/y, FCF and FCF margin, adjusted FCF and capex as reported; `Gd:` FCF.
8. **GUIDANCE vs ACTUAL** — `section(..., period_labels=True)` so the band shows every column's period and the fiscal-year roll is visible. Match the grid to what the company actually guides:

   | Company guides | Quarterly grid rows | FY columns |
   |---|---|---|
   | Quarterly revenue + organic growth + OI, and FY revenue/OI (TWLO) | rev lo/hi/mid, implied y/y, act vs mid; organic lo/hi, act − high; OI lo/hi/mid, act vs mid | latest FY OI guide, FY revenue growth guide |
   | Quarterly revenue + GM + EPS only, no FY revenue/OI (INTC) | rev lo/hi/mid, implied y/y, act vs mid; GM guide, act − guide (pts); EPS guide, act − guide ($) | whatever FY targets it gives (opex, capex, FCF) |

   Always add a **FY gd given on** row naming the call each FY figure came from (e.g. "3Q26 call, prelim floor"), give floors a `"≥"` number format, and end with an LT targets text row (source and date).
9. **COMMENTS** — one `percol_row` per theme.
10. Key line (Gd = guidance on that call, Discl = disclosure for the quarter, blue = transcript hardcode, ↑/↓), then the footer `Generated ...` and `FOOT = r`.

Row-helper reference and the required row keys (`rev`, `gp`, `oi`, `eps`, `shs`, plus each `sens_segments` key) are in the example spec's header.

### What the engine produces

- **Columns:** B labels · 4 hidden y/y helper quarters · 12 trailing actual quarters · 8 consensus quarters (grey) · hidden FY helper · 3 FY actuals · 3 FY consensus · gap · 3 sensitization columns (off-print). Quarter columns are about 9 wide so per-column text wraps legibly.
- **Label hierarchy:** the `indent` argument on each row helper sets the level (2 Excel indent units per level). Headline rows (segment revenue, GP, OI) sit at 0; their y/y, q/q and % of total at 1; sub-rows (organic, mgmt-disclosed, calc ex-one-off, segment margins, units/ASP) at 2. Keep every row's indent at the level it belongs to, so the column reads as an outline rather than a flush-left list.
- **Growth calcs:** y/y and q/q show blank when the prior period is zero or negative, so losses and eliminations never print meaningless percentages.
- **Lines:** a thin vertical line at each fiscal-year start (every 1Q column and every FY column), and a heavy line where consensus begins and where the FY block begins.
- **VA formulas:** `=IFERROR(_xll.VisibleAlpha.UDF.VAData(Ref!$B$2,"3Q-26","<VA name>")/Ref!$B$3,"")`. The ticker lives once in `Ref!B2`; `Ref!B3` is the unit divisor (1 = VA returns $mm, 1000000 = raw $). Per-share and ASP rows use `scale=False`; unit counts are scaled to millions.
- **Hidden Ref sheet:** period keys, VA line items used, earnings dates (`_xll.VADetail("EarningsDate",...)` in live mode, call dates in values mode).
- **Sensitization:** "Earnings Power — inputs in blue". Yellow inputs, seeded from consensus, for segment growth, other/elims, GM %, opex % of revenue, OI-to-net-income conversion and shares. These flow to revenue, OI, EPS and the % gap vs consensus.
- **Print:** landscape letter, fixed scale with a manual break before Gross Profit, title rows repeated. Two pages is the target.

Run it:
```bash
python3 scripts/qr_build.py <ticker>_spec.py live <TICKER>_QR.xlsx 49
```
Never run recalc.py on the live file: `_xll.*` cannot evaluate in LibreOffice and would bake `#NAME?` into every cell.

## Step 5 — Values copy, verification, PDF

```bash
python3 scripts/qr_build.py <ticker>_spec.py values <TICKER>_QR_values.xlsx 49
```
```bash
python3 /mnt/skills/public/xlsx/scripts/recalc.py <TICKER>_QR_values.xlsx 60
```
```bash
soffice --headless --convert-to pdf --outdir pdf <TICKER>_QR_values.xlsx
```
1. Recalc must report `total_errors: 0`.
2. Tie VA to the calls: for every reported quarter, VA GM and EPS (or OI) should match the figures management gave on the call. Then spot-check the latest quarter's revenue and segment y/y against the transcript figures. A subagent that retyped values by hand makes these checks essential.
3. Scan the values copy for absurd outputs (growth rates in the thousands of percent, sensitization seeds far from consensus growth). Each one points to a series break from Step 2; fix it in the spec, not by editing cells.
4. Sensitization FY+1 to FY+3 revenue and EPS must equal consensus (gap 0.0%).
5. The PDF must be 2 pages at full width. If `pdfinfo` shows more pages, lower the scale argument by 1-2 and rebuild both files. Render the pages to PNG and look at them: wrapped text readable, labels indented by level, lines in place, page 2 starting at Gross Profit.

## Step 6 — Deliver

Save `<TICKER>_QR.xlsx` (live) and `<TICKER>_QR.pdf` (the values-copy render) in the working directory, commit and push if it is a repo, and send both with download cards (SendUserFile, `display: attach`) so Bobby can download them in the chat. Chat summary:
- every segment included, with latest-quarter y/y and next-quarter consensus y/y
- the latest guide vs actual and the next-quarter guide
- how the guidance block was adapted to what the company guides
- series VA doesn't carry, broken series dropped or shown as levels, VA-derived series, any basis change and its effect on the live file
- the VA ticker key and `Ref!B3` unit check
- that the xlsx refreshes via the VA add-in

## Failure modes

| Situation | Action |
|---|---|
| VA not logged in (Chrome route) | Stop and tell Bobby |
| Company discloses a segment VA lacks | `hard_row` with transcript values (blue); flag in chat |
| Company stopped disclosing a split | Keep the VA series, note it in the `Discl:` row and a cell comment |
| Company doesn't disclose GP/GM, or segment GP doesn't tie | Skip those rows; adapt the sections, never force the metric list |
| Company gives no FY revenue/OI guidance | Use the quarterly revenue/GM/EPS grid and put its FY targets (opex, capex) in the FY columns |
| Per-column text too long | Cut to the essential numbers; overflow goes to a cell comment |
| Guide is a floor or a preliminary | `≥` format plus the "given on" source cell |
