# QR Shorthand Glossary

Goal: compress guidance and disclosure language into short cells that sit in the column of the quarter they belong to, so a row reads as a progression left to right.

## Cell format
One item per cell, in the column of the call it was given on (Gd) or the quarter it describes (Discl). No quarter tag is needed; the column is the tag. Name the fiscal year inside guidance text whenever it is not the column's own year.
- Gd (given on the 3Q26 call, in the 3Q26 column): `FY26 org ↑15%, rep ↑20% | FY27 prelim org ≥10%`
- Discl (in the 3Q26 column): `~60% of rev; 17% org (vs 18% 2Q)`

Aim for 45 characters or fewer (about 3 wrapped lines in a 9-wide column). Use at most 2 pipe segments; overflow goes to a cell comment.

When a disclosure is a number that recurs (organic growth, net expansion, a fee contribution, segment growth), put it in a numeric `hard_row`, not text. The trend should be readable as numbers.

## Growth-rate shorthand
| Phrase | Shorthand |
|---|---|
| low/mid/high single digit | LSD / MSD / HSD |
| low/mid/high teens | Lteens / Mteens / Hteens |
| low/mid/high 20s (etc.) | L20s / M20s / H20s |
| double digit | DD |
| year over year / quarter over quarter / sequential | y/y / q/q / seq |
| approximately | ~ |
| greater/less than | > / < |
| flat / roughly flat | flat / ~flat |
| down slightly | -LSD (or dn slightly) |

## Timing / cadence
| Phrase | Shorthand |
|---|---|
| back-half weighted | 2H wtd |
| first-half weighted | 1H wtd |
| exiting the year at | exit @ |
| second half of FY26 | 2H26 |
| by end of calendar 2026 | by CY26-end |
| ramping through the year | ramps thru yr |

## Financial terms
| Phrase | Shorthand |
|---|---|
| gross margin / operating margin | GM / OM |
| basis points | bps |
| constant currency | cc |
| excluding | ex- |
| revenue | rev |
| organic / reported | org / rep |
| incremental margin | incr mgn |
| capacity | cap |
| utilization | util |
| customer | cust |
| self-serve | SS |
| dollar-based net expansion | DBNE |
| top customer 20% of revenue | top cust 20% of rev |
| design win | DW |
| long-term agreement / take-or-pay | LTA / ToP |
| record | rcd |
| investor / analyst day | ID |

## Guidance qualifiers
| Phrase | Shorthand |
|---|---|
| guided / guidance | gd |
| raised / lowered / maintained | ↑ / ↓ / mnt |
| above/below prior guide | > prior / < prior |
| initiated FY guide | init FY gd |
| preliminary / floor | prelim / ≥ |
| withdrew guidance | w/d gd |

## Rules
- Keep numbers as numbers (~15%, never approximately fifteen percent)
- Keep the unit only when it is ambiguous ($, units, bits)
- When management revises a guide, every call's version stays in its own column with ↑/↓, so the revision chain reads across the row
- In the guidance grid, every FY guide carries a "given on" source cell (e.g. 3Q26 call, prelim floor)
