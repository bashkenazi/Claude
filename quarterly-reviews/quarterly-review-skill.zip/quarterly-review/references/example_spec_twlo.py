# Per-company QR spec — worked example (Twilio, built 2026-11-03).
# Copy this file to <ticker>_spec.py, then replace META, the ledgers and build_body() for the new company.
# The engine (scripts/qr_build.py) exec's this file, so build_body() can call the engine's row helpers:
#   section(title, period_labels=False)   blue band; period_labels=True repeats period/FY labels in the band
#   growth_block(key, label, va_item, bold, indent, mix=True, qoq=True)   VA row + y/y + q/q + % of total
#   va_row(key, label, va_item, fmt, scale=True)   one VAData row (scale=False for per-share / % items)
#   calc_row(key, label, fn(cx)->formula, fmt, kinds=("q","fy"))   Excel formula row; yy(key) qq(key) ratio(a,b) helpers
#   hard_row(key, label, {"YYYY Qn": value}, fmt)   blue transcript-sourced numbers in the quarter disclosed
#   percol_row(tag, label, {"YYYY Qn": text})        wrapped shorthand in the column of the call / quarter
#   gd_row(...) is defined inside build_body below (quarterly guide grid from Q_GUIDE)
# Required row keys for the engine: rev, gp, oi, eps, shs, plus every key in META["sens_segments"].

META = {
    "va_ticker": "TWLO_US",                     # read off VA / va_company_data resolve; never guessed
    "short": "TWLO",
    "title": "Twilio Inc. (TWLO)",
    "va_json": "twlo_va.json",                  # captured VA values, same folder as this spec
    "last_actual": (2026, 3),                   # last reported fiscal quarter (FY, Q)
    "fiscal_note": "FYE December (FY = CY)",
    "source_note": "VA via SRS MCP (va_company_id 21070) + Quartr transcripts",
    "sens_segments": [("comms", "Communications"), ("seg", "Segment")],
    "earnings_dates": {"2023 Q3": "2023-11-08", "2023 Q4": "2024-02-14", "2024 Q1": "2024-05-07", "2024 Q2": "2024-08-01",
        "2024 Q3": "2024-10-30", "2024 Q4": "2025-02-13", "2025 Q1": "2025-05-01", "2025 Q2": "2025-08-07",
        "2025 Q3": "2025-10-30", "2025 Q4": "2026-02-12", "2026 Q1": "2026-04-30", "2026 Q2": "2026-08-06",
        "2026 Q3": "2026-10-29"},
}


# Quarterly guide FOR period P (given on prior quarter's call)
Q_GUIDE = {
    # period: (rev_lo, rev_hi, org_yy_lo, org_yy_hi, oi_lo, oi_hi)
    "2023 Q4": (1030, 1040, .04, .05, 115, 125),
    "2024 Q1": (1025, 1035, .05, .06, 120, 130),
    "2024 Q2": (1050, 1060, .04, .05, 135, 145),
    "2024 Q3": (1085, 1095, .05, .06, 160, 170),
    "2024 Q4": (1150, 1160, .07, .08, 185, 195),
    "2025 Q1": (1130, 1140, .08, .09, 180, 190),
    "2025 Q2": (1180, 1190, .09, .10, 195, 205),
    "2025 Q3": (1245, 1255, .08, .09, 205, 215),
    "2025 Q4": (1310, 1320, .08, .09, 230, 240),
    "2026 Q1": (1335, 1345, .10, .11, 240, 250),
    "2026 Q2": (1420, 1430, .10, .11, 250, 260),
    "2026 Q3": (1505, 1515, .11, .12, 285, 295),
    "2026 Q4": (1595, 1605, .11, .12, 300, 310),
}

# ---------- Guidance given on each call (text, per call-quarter column) ----------
GD_FYREV = {
    "2023 Q4": "FY24: y/y growth thru yr; no range",
    "2024 Q1": "FY24 org 5-10% (reit)",
    "2024 Q2": "FY24 org 6-7% (narrowed)",
    "2024 Q3": "FY24 org ↑7.5-8%; FY25 prelim 7-8%",
    "2024 Q4": "FY25 org 7-8% (mnt)",
    "2025 Q1": "FY25 org ↑7.5-8.5%",
    "2025 Q2": "FY25 org ↑9-10%; rep 10-11% (init)",
    "2025 Q3": "FY25 org ↑11.3-11.5%; rep ↑12.4-12.6%",
    "2025 Q4": "FY26 init: org 8-9%, rep 11.5-12.5%",
    "2026 Q1": "FY26 org ↑9.5-10.5%; rep ↑14-15%",
    "2026 Q2": "FY26 org ↑13-13.5%; rep ↑18-18.5%",
    "2026 Q3": "FY26 org ↑15%, rep ↑20% | FY27 prelim org ≥10%",
}
GD_FEES = {
    "2025 Q2": "~$20M/qtr in 3Q & 4Q25",
    "2025 Q3": "4Q25 ~$22M",
    "2025 Q4": "FY26 ~$190M; 1Q26 $44M",
    "2026 Q1": "FY26 ~$235M; 2Q26 $71M",
    "2026 Q2": "FY26 ~$250M; 3Q26 $56M",
    "2026 Q3": "FY26 ~$245M; 4Q26 ~$75M",
}
GD_SEG = {
    "2024 Q1": "Seg OI breakeven by 2Q25; growth muted",
    "2024 Q2": "Seg breakeven 2Q25; FY growth muted",
    "2024 Q3": "Seg breakeven 2Q25; migration done 4Q",
    "2024 Q4": "Seg breakeven by 2Q25",
    "2025 Q1": "Seg breakeven in 2Q25",
    "2025 Q2": "No BU results from 3Q25",
}
GD_GM = {
    "2024 Q1": "Seg GM ↓ thru yr (migration)",
    "2024 Q3": "4Q GM modest seq ↓ (holiday)",
    "2024 Q4": "GM ~flat over multi-yr",
    "2025 Q2": "GM stabilizes ex-fees; fees -50bps 3Q/4Q",
    "2025 Q4": "FY26 GP$ ≈ org rev; fees -170bps GM",
    "2026 Q1": "FY26 GP$ ≈ org rev; fees -200bps GM",
    "2026 Q2": "FY26 GP$ ≈ org rev; fees -210bps GM",
    "2026 Q3": "FY26 fees ~-200bps; 4Q GP ≈ org growth",
}
GD_OI = {
    "2023 Q4": "FY24 OI > FY23 $533M (incl ~$90M bonus)",
    "2024 Q1": "FY24 OI ↑$585-635M (from $550-600M)",
    "2024 Q2": "FY24 OI ↑$650-675M",
    "2024 Q3": "FY24 OI ↑$700-710M",
    "2024 Q4": "FY25 OI $825-850M | ID: FY27 OM 21-22%",
    "2025 Q1": "FY25 OI ↑$850-875M",
    "2025 Q2": "FY25 OI $850-875M (mnt)",
    "2025 Q3": "FY25 OI ↑$900-910M",
    "2025 Q4": "FY26 OI $1.04-1.06B | FY27 ≥$1.23B",
    "2026 Q1": "FY26 OI ↑$1.08-1.10B",
    "2026 Q2": "FY26 OI ↑$1.135-1.155B",
    "2026 Q3": "FY26 OI ↑$1.19-1.20B | FY27 ≥$1.35B",
}
GD_FCF = {
    "2024 Q1": "FY24 FCF ≈ OI",
    "2024 Q3": "FY24 FCF $650-675M",
    "2024 Q4": "ID: $3B+ cum FCF FY25-27",
    "2025 Q1": "FY25 FCF ↑$850-875M",
    "2025 Q2": "FY25 FCF ↑$875-900M",
    "2025 Q3": "FY25 FCF ↑$920-930M",
    "2025 Q4": "FY26 FCF $1.04-1.06B; 1Q ~$100M",
    "2026 Q1": "FY26 FCF ↑$1.08-1.10B",
    "2026 Q2": "FY26 FCF ↑$1.135-1.155B",
    "2026 Q3": "FY26 FCF ↑$1.19-1.20B | FY27 ≥$1.35B",
}
# FY guidance in FY columns: latest guide + the call it came from
FY_GD_REV = {"2024": .0775, "2025": .125, "2026": .20, "2027": .10}
FY_GD_OI = {"2024": (700, 710), "2025": (900, 910), "2026": (1190, 1200), "2027": (1350, 1350)}
FY_GD_SRC = {"2024": "3Q24 call (org)", "2025": "3Q25 call (rep)", "2026": "3Q26 call (rep)", "2027": "3Q26 call, prelim floor (org)"}

# ---------- Numeric disclosures (per reported-quarter column) ----------
MSG_YY_MGMT = {"2026 Q1": .25, "2026 Q2": .28, "2026 Q3": .24}
MSG_FEE_PTS = {"2026 Q1": .07, "2026 Q2": .10, "2026 Q3": .07}
MSG_ORG_MGMT = {"2026 Q1": .18, "2026 Q2": .18, "2026 Q3": .17}
DBNE = {"2023 Q4": 1.02, "2024 Q1": 1.02, "2024 Q2": 1.02, "2024 Q3": 1.05, "2024 Q4": 1.06, "2025 Q1": 1.07,
        "2025 Q2": 1.08, "2025 Q3": 1.09, "2025 Q4": 1.09, "2026 Q1": 1.14, "2026 Q2": 1.16, "2026 Q3": 1.14}
DBNE_FEE = {"2025 Q2": .006, "2026 Q1": .04, "2026 Q2": .05, "2026 Q3": .04}
DBNE_COMMS = {"2023 Q4": 1.02, "2024 Q1": 1.03, "2024 Q2": 1.02, "2024 Q3": 1.06, "2024 Q4": 1.08, "2025 Q1": 1.08, "2025 Q2": 1.09}
DBNE_SEG = {"2023 Q4": .96, "2024 Q1": .92, "2024 Q2": .93, "2024 Q3": .91, "2024 Q4": .93, "2025 Q1": .94, "2025 Q2": .95}

# ---------- Text disclosures (per reported-quarter column) ----------
D_TOTAL = {
    "2023 Q4": "Org +8% (ex-crypto +10%); 9-fig msg deal",
    "2024 Q1": "Org +7%; ex crypto/Zipwhip +9%",
    "2024 Q2": "Org +7%; SS strongest since 1Q23",
    "2024 Q3": "Org = rep +10%; SS particularly strong",
    "2024 Q4": "78 deals ≥$500K (+47%); 325K+ custs",
    "2025 Q1": "$500K+ custs +37%; 300K+ custs",
    "2025 Q2": "$500K+ deals +57%; SS/ISV/intl DD",
    "2025 Q3": "SS & ISV 20%+; intl +18%; 9-fig renewal",
    "2025 Q4": "SS +28%, ISV +26%; multi-prod custs +26%",
    "2026 Q1": "SS & ISV 25%+; multi-prod custs +29%",
    "2026 Q2": "SS 30%+, ISV 25%+; $1M+ custs +20%+",
    "2026 Q3": "SS 30%+ (~15% of rev), ISV 20%+",
}
D_COMMS = {
    "2023 Q4": "Org +8%; ex-crypto DBNE 104%",
    "2024 Q1": "Org +7%; ex-items +10%; GM 52.2%",
    "2024 Q2": "Org +7%; Zipwhip -100bps",
    "2024 Q3": "GM 51.8%; OI $268M",
    "2024 Q4": "GM 50.6%",
    "2025 Q1": "GM 49.8%",
    "2025 Q2": "Last qtr split disclosed",
    "2025 Q3": "Split no longer disclosed",
}
D_SEG = {
    "2023 Q4": "$286M impairment (GAAP)",
    "2024 Q1": "GM 77.6%; loss $21M",
    "2024 Q2": "Loss $16M; 40%+ multi-yr bookings",
    "2024 Q3": "GM 69.8%; loss $16M",
    "2024 Q4": "GM 72.3% (migration done)",
    "2025 Q1": "GM 74%; churn lowest since 1Q23",
    "2025 Q2": "OI +$6M (breakeven hit)",
    "2025 Q4": "FY25 Segment +2%",
}
D_MSG = {
    "2023 Q4": "Largest msg deal ever (9-fig)",
    "2024 Q1": "Vols stabilized, not inflected",
    "2024 Q2": "Solid; intl modestly better",
    "2024 Q3": "Accelerated",
    "2024 Q4": "Accel 2nd straight qtr",
    "2025 Q1": "Strong US & intl",
    "2025 Q2": "Accel 4th straight qtr",
    "2025 Q3": "Hteens 2nd qtr; RCS vol >2x q/q",
    "2025 Q4": "~58% of rev; FY25 +18%; RCS ~5x q/q",
    "2026 Q1": "RCS vol >2x q/q; ~18% operationally",
    "2026 Q2": "RCS mgn ≈ msg; 18% ex-fees",
    "2026 Q3": "~60% of rev; 17% org (vs 18% 2Q)",
}
D_VOICE = {
    "2023 Q4": "Voice Intel beta: 42M call min",
    "2024 Q3": "AI not material for a while",
    "2024 Q4": "9K+ AI cos; voice ~12% of rev, +6% (ID)",
    "2025 Q2": "DD, 1st time in 2 yrs",
    "2025 Q3": "Mteens, fastest 3+ yrs; voice AI custs ~+60%",
    "2025 Q4": "Hteens; voice AI rev >+60%; FY25 +13%",
    "2026 Q1": "+20%, 6th accel qtr; SS voice +45%",
    "2026 Q2": ">20%; SS voice +50%+",
    "2026 Q3": "+20%+; SS voice 50%+; AI ~1% of interactions",
}
D_EMAIL = {
    "2024 Q2": "Accelerating",
    "2024 Q3": "Continued strong",
    "2024 Q4": "Strong",
    "2025 Q2": "Cloud migration: double cost",
    "2025 Q3": "Free tier ended; drove cust adds",
    "2025 Q4": "FY25 +7%",
    "2026 Q2": "Mgns improving (migration lapped)",
    "2026 Q3": "Steady, slightly < co avg",
}
D_OTHER = {
    "2024 Q2": "AI SW: Verify, Voice Intel",
    "2025 Q1": "Verify, SMS pumping >> co avg",
    "2025 Q2": "SW add-ons DD",
    "2025 Q3": "Verify >25%",
    "2025 Q4": "Add-ons >20%; Verify >25%; Branded Calling ~6x",
    "2026 Q1": "Add-ons >20%; BC & CI >100%",
    "2026 Q2": "Add-ons 25%+; Verify 30%+",
    "2026 Q3": "Add-ons 25%+; services 30%+; 1st 8-fig Conversations deal",
}
D_GM = {
    "2023 Q4": "52.4%; 10DLC fees, intl mix",
    "2024 Q1": "54.1%; hosting credit ~80bps",
    "2024 Q2": "53.3%; credits did not recur",
    "2024 Q3": "52.9%",
    "2024 Q4": "52.0%; holiday hosting, msg mix",
    "2025 Q1": "51.3%; intl msg mix",
    "2025 Q2": "50.7%; msg mix -260bps",
    "2025 Q3": "50.1%; ~flat q/q ex-fees",
    "2025 Q4": "49.9%; fees ~80bps",
    "2026 Q1": "49.6% (-180bps y/y)",
    "2026 Q2": "49.1%; ex-fees +60bps y/y",
    "2026 Q3": "49.2%; ex-fees +80bps y/y",
}
D_OI = {
    "2023 Q4": "SBC 15.3% of rev",
    "2024 Q1": "Bonus -180bps OM",
    "2024 Q2": "SBC 13.6%; $20M bonus cost",
    "2024 Q3": "$18M bonus catch-up",
    "2024 Q4": "$17M Oi bad debt; 1st GAAP profit",
    "2025 Q1": "SBC 11.9%",
    "2025 Q2": "Merit + SIGNAL costs",
    "2025 Q3": "OM +190bps y/y",
    "2025 Q4": "FY25 opex -1%",
    "2026 Q1": "SBC 9.7%; fees -70bps OM",
    "2026 Q2": "Fees -90bps OM; SBC 9.5%",
    "2026 Q3": "OM 21%; OI +39% y/y",
}
COMMENTS = [
 ("Voice AI / AI natives", {
   "2026 Q3": "POCs → production", "2026 Q2": "$6M & $9M run-rate AI-native custs", "2026 Q1": "Demand 'unprecedented'",
   "2025 Q4": "Voice AI rev >+60%", "2025 Q3": "Top-10 voice AI startups >10x", "2025 Q2": "ConvRelay ~1M calls 1st GA qtr",
   "2024 Q4": "9K+ AI cos; not material", "2024 Q3": "Not material for a while"}),
 ("Capital return / M&A", {
   "2026 Q3": "Buyback $127M; ~$700M left", "2026 Q2": "Buyback $66M; $944M tax VA release",
   "2025 Q3": "Buyback $350M; Stytch <$100M", "2025 Q2": "Buyback $177M",
   "2025 Q1": "Buyback $130M; $2B auth thru '27", "2024 Q4": "$2.3B+ returned '24; shs -16%",
   "2024 Q2": "$700M+ since May", "2023 Q4": "$730M of $1B done"}),
]
LT_TARGETS = "ID 2025-01-23: FY27 non-GAAP OM 21-22%; $3B+ cum FCF FY25-27; SBC ~10% of rev; ~50% FCF returned | 3Q26: FY27 OI ≥$1.35B"


def build_body():
    global r, FOOT, PB_ROW
    # ---------- Total revenue ----------
    section("TOTAL REVENUE")
    growth_block("rev", "Total revenue", "Revenue", bold=True)
    va_row("org", "Organic revenue (ex incr. US carrier fees)", "Revenue - Organic", indent=1)
    calc_row("org_yy", "Organic y/y", lambda cx: (None if prev(cx, 4 if cx["kind"] == "q" else 1) is None else
             f'=IFERROR(IF(N({L(prev(cx, 4 if cx["kind"] == "q" else 1))}{ROWS["rev"]})=0,"",{L(cx["col"])}{ROWS["org"]}/{L(prev(cx, 4 if cx["kind"] == "q" else 1))}{ROWS["rev"]}-1),"")'), indent=2)
    calc_row("fees", "Carrier-fee pass-thru (rev − organic)", lambda cx: f'=IFERROR({L(cx["col"])}{ROWS["rev"]}-{L(cx["col"])}{ROWS["org"]},"")', fmt=FMT_D, indent=2)
    percol_row("Gd:", "FY revenue (given on call)", GD_FYREV)
    percol_row("Gd:", "Carrier-fee pass-thru", GD_FEES)
    percol_row("Discl:", "Go-to-market / customers", D_TOTAL)
    hard_row("dbne", "DBNE — total (mgmt)", DBNE, fmt='0%;(0%);"-"')
    hard_row("dbne_fee", "  carrier-fee contribution (pts)", DBNE_FEE, fmt='0.0%;(0.0%);"-"')
    calc_row("dbne_x", "DBNE ex-fees (calc)", lambda cx: f'=IF(N({L(cx["col"])}{ROWS["dbne"]})=0,"",{L(cx["col"])}{ROWS["dbne"]}-{L(cx["col"])}{ROWS["dbne_fee"]})', fmt='0%;(0%);"-"', kinds=("q",), indent=1)
    hard_row("dbne_c", "DBNE — Communications (mgmt)", DBNE_COMMS, fmt='0%;(0%);"-"')
    hard_row("dbne_s", "DBNE — Segment (mgmt)", DBNE_SEG, fmt='0%;(0%);"-"')

    # ---------- Reported segments ----------
    section("REPORTED SEGMENTS")
    growth_block("comms", "Twilio Communications", "Revenue - Communication", bold=True)
    percol_row("Discl:", "Communications", D_COMMS, "Company stopped reporting Comms/Segment split after 2Q25; later values per VA.")
    growth_block("seg", "Twilio Segment", "Revenue - Segments", bold=True)
    percol_row("Gd:", "Segment", GD_SEG)
    percol_row("Discl:", "Segment", D_SEG)
    calc_row("elim", "Intersegment / unallocated (total − segments)",
             lambda cx: f'=IFERROR({L(cx["col"])}{ROWS["rev"]}-{L(cx["col"])}{ROWS["comms"]}-{L(cx["col"])}{ROWS["seg"]},"")', fmt=FMT_D, italic=True, indent=1)

    # ---------- Product lines ----------
    section("REVENUE BY PRODUCT (company discloses annually; quarterly per VA)")
    growth_block("msg", "Messaging", "Revenue - Messaging", bold=True)
    hard_row("msg_m", "Messaging y/y — mgmt reported", MSG_YY_MGMT, indent=2)
    hard_row("msg_f", "  carrier-fee contribution (pts) — mgmt", MSG_FEE_PTS, indent=2)
    hard_row("msg_o", "Messaging organic y/y — mgmt", MSG_ORG_MGMT, indent=2, bold=True)
    calc_row("msg_x", "Messaging ex all carrier fees y/y (calc)",
             lambda cx: None if prev(cx, 4 if cx["kind"] == "q" else 1) is None else
             '=IFERROR(IF(N({p}{m})=0,"",({c}{m}-N({c}{f}))/{p}{m}-1),"")'.format(c=L(cx["col"]), p=L(prev(cx, 4 if cx["kind"] == "q" else 1)), m=ROWS["msg"], f=ROWS["fees"]),
             indent=2)
    ws.cell(ROWS["msg_x"], 2).comment = Comment("(Messaging − total carrier-fee pass-thru) ÷ prior-yr messaging − 1. Fees = total rev − organic rev (VA); all fees are US A2P messaging. Tracks mgmt organic within ~1pt.", "QR")
    percol_row("Discl:", "Messaging", D_MSG)
    growth_block("voice", "Voice", "Revenue - Voice", bold=True)
    percol_row("Discl:", "Voice", D_VOICE)
    growth_block("email", "Email", "Revenue - Email", bold=True)
    percol_row("Discl:", "Email", D_EMAIL)
    growth_block("other", "Other (SW add-ons, Verify, services)", "Revenue - Other", bold=True)
    percol_row("Discl:", "Other / add-ons", D_OTHER)
    growth_block("nonmsg", "Non-messaging (memo)", "Revenue - Non-messaging", indent=0)
    calc_row("precon", "Product recon (total − msg − voice − email − Segment − other)",
             lambda cx: "=IFERROR({c}{t}-{c}{a}-{c}{b}-{c}{e}-{c}{s}-{c}{o},\"\")".format(
                 c=L(cx["col"]), t=ROWS["rev"], a=ROWS["msg"], b=ROWS["voice"], e=ROWS["email"], s=ROWS["seg"], o=ROWS["other"]),
             fmt=FMT_D, indent=1)

    # ---------- Geography / customers ----------
    section("REVENUE BY GEOGRAPHY / CUSTOMER")
    growth_block("us", "United States", "Revenue - United States", bold=True)
    growth_block("intl", "International", "Revenue - International", bold=True)
    growth_block("top10", "Top-10 active customer accounts", "Revenue from10 largest active customer account", qoq=False)
    growth_block("newc", "New-customer revenue", "Total revenue - New customer", qoq=False)
    growth_block("exist", "Existing-customer revenue", "Total revenue - Existing customers", qoq=False)

    # ---------- Margins ----------
    PB_ROW = r - 1
    section("GROSS PROFIT (non-GAAP)")
    va_row("gp", "Gross profit", "Gross profit/(loss) - Operating", bold=True)
    calc_row("gp_yy", "y/y", yy("gp"))
    calc_row("gm", "Gross margin", ratio("gp", "rev"), bold=True, italic=False)
    va_row("gp_c", "GP — Communications", "Gross profit/(loss) - Communications - Operating", indent=1)
    calc_row("gm_c", "GM — Communications", ratio("gp_c", "comms"), indent=2)
    va_row("gp_s", "GP — Segment", "Gross profit/(loss) - Segments - Operating", indent=1)
    calc_row("gm_s", "GM — Segment", ratio("gp_s", "seg"), indent=2)
    percol_row("Gd:", "Gross margin", GD_GM)
    percol_row("Discl:", "Gross margin", D_GM)

    section("OPERATING INCOME (non-GAAP)")
    va_row("oi", "Income from operations", "Income/(loss) from operations - Operating", bold=True)
    calc_row("oi_yy", "y/y", yy("oi"))
    calc_row("om", "Operating margin", ratio("oi", "rev"), bold=True, italic=False)
    va_row("oi_c", "OI — Communications", "Income/(loss) from operations - Communication - Operating", indent=1)
    calc_row("om_c", "OM — Communications", ratio("oi_c", "comms"), indent=2)
    va_row("oi_s", "OI — Segment", "Income/(loss) from operations - Segments - Operating", indent=1)
    calc_row("om_s", "OM — Segment", ratio("oi_s", "seg"), indent=2)
    va_row("oi_corp", "Corporate costs", "Income/(loss) from operations - Corporate costs - Operating", indent=1)
    va_row("oi_gaap", "GAAP income from operations (memo)", "Income/(loss) from operations", indent=1)
    percol_row("Gd:", "Operating income", GD_OI)
    percol_row("Discl:", "Operating income", D_OI)

    section("EPS / SHARES / CASH FLOW")
    va_row("eps", "EPS — diluted, non-GAAP", "EPS applicable to common stockholder - Diluted - Operating", fmt=FMT_E, scale=False, bold=True)
    calc_row("eps_yy", "y/y", yy("eps"))
    va_row("shs", "Diluted shares (mm)", "Shares - Diluted", fmt='#,##0.0;(#,##0.0);"-"')
    calc_row("shs_yy", "y/y", yy("shs"))
    va_row("fcf", "Free cash flow", "Free cash flow", bold=True)
    calc_row("fcfm", "FCF margin", ratio("fcf", "rev"))
    percol_row("Gd:", "Free cash flow", GD_FCF)

    # ---------- Guidance block ----------
    section("GUIDANCE vs ACTUAL — qtr guide given on prior call; FY = latest guide", period_labels=True)
    def gd_row(key, label, idx=None, fmt=FMT_D, fy=None, fyfmt=None):
        global r
        ROWS[key] = r
        put_label(r, label, indent=1)
        for cx in QCOLS:
            g = Q_GUIDE.get(cx["dkey"])
            if g and idx is not None:
                cl = ws.cell(r, cx["col"], g[idx]); cl.font = font(color=BLUE); cl.number_format = fmt
        if fy:
            for k, v in fy.items():
                cl = ws.cell(r, BYKEY[k]["col"], v); cl.font = font(color=BLUE); cl.number_format = fyfmt or fmt
        r += 1
    gd_row("g_rlo", "Rev gd — low", 0)
    gd_row("g_rhi", "Rev gd — high", 1)
    calc_row("g_rmid", "Rev gd — mid", lambda cx: f'=IF(COUNT({L(cx["col"])}{ROWS["g_rlo"]}:{L(cx["col"])}{ROWS["g_rhi"]})=2,AVERAGE({L(cx["col"])}{ROWS["g_rlo"]}:{L(cx["col"])}{ROWS["g_rhi"]}),"")', fmt=FMT_D, kinds=("q",), italic=False)
    calc_row("g_ryy", "Rev gd mid — implied y/y", lambda cx: None if prev(cx, 4) is None else
             f'=IFERROR(IF({L(cx["col"])}{ROWS["g_rmid"]}="","",{L(cx["col"])}{ROWS["g_rmid"]}/{L(prev(cx,4))}{ROWS["rev"]}-1),"")', kinds=("q",))
    calc_row("g_rbeat", "Rev act (or cons) vs gd mid", lambda cx: f'=IFERROR(IF({L(cx["col"])}{ROWS["g_rmid"]}="","",{L(cx["col"])}{ROWS["rev"]}/{L(cx["col"])}{ROWS["g_rmid"]}-1),"")', kinds=("q",), bold=True, italic=False)
    gd_row("g_olo", "Organic y/y gd — low", 2, fmt=FMT_P)
    gd_row("g_ohi", "Organic y/y gd — high", 3, fmt=FMT_P)
    calc_row("g_obeat", "Organic y/y act − gd high (pts)", lambda cx: f'=IFERROR(IF(N({L(cx["col"])}{ROWS["g_ohi"]})=0,"",{L(cx["col"])}{ROWS["org_yy"]}-{L(cx["col"])}{ROWS["g_ohi"]}),"")', kinds=("q",))
    gd_row("g_oilo", "OI gd — low", 4, fy={k: v[0] for k, v in FY_GD_OI.items()})
    gd_row("g_oihi", "OI gd — high", 5, fy={k: v[1] for k, v in FY_GD_OI.items()})
    calc_row("g_oimid", "OI gd — mid", lambda cx: f'=IF(COUNT({L(cx["col"])}{ROWS["g_oilo"]}:{L(cx["col"])}{ROWS["g_oihi"]})=2,AVERAGE({L(cx["col"])}{ROWS["g_oilo"]}:{L(cx["col"])}{ROWS["g_oihi"]}),"")', fmt=FMT_D, italic=False)
    calc_row("g_oibeat", "OI act (or cons) vs gd mid", lambda cx: f'=IFERROR(IF({L(cx["col"])}{ROWS["g_oimid"]}="","",{L(cx["col"])}{ROWS["oi"]}/{L(cx["col"])}{ROWS["g_oimid"]}-1),"")', bold=True, italic=False)
    gd_row("g_fyrev", "FY rev y/y gd (latest guide)", None, fy=FY_GD_REV, fyfmt=FMT_P)
    # FY27 guides are floors -> show the ≥ sign
    for key in ("g_oilo", "g_oihi", "g_oimid"):
        ws.cell(ROWS[key], BYKEY["2027"]["col"]).number_format = '"≥"#,##0'
    ws.cell(ROWS["g_fyrev"], BYKEY["2027"]["col"]).number_format = '"≥"0.0%'
    # which call each FY guide came from
    ROWS["g_src"] = r
    put_label(r, "FY gd given on", indent=1, italic=True)
    for k, t in FY_GD_SRC.items():
        cl = ws.cell(r, BYKEY[k]["col"], t); cl.font = font(italic=True, size=5.5, color=BLUE)
        cl.alignment = Alignment(wrap_text=True, vertical="top", horizontal="center")
    ws.row_dimensions[r].height = 22
    r += 1
    ws.cell(ROWS["g_rlo"], FIRST_VIS_Q).comment = Comment("Quarterly guides from Quartr transcripts (prior-quarter calls). Hardcoded = blue.", "QR")
    percol_row("LT targets:", "", {next(x for x in QCOLS if not x["hidden"])["dkey"]: LT_TARGETS})
    ws.row_dimensions[r - 1].height = 9.5
    ws.cell(r - 1, FIRST_VIS_Q).alignment = Alignment(wrap_text=False)

    # ---------- Comments ----------
    section("COMMENTS (per-quarter shorthand)")
    for theme, cells in COMMENTS:
        percol_row("", theme, cells)
    r += 1
    ws.cell(r, 2, "Gd = guidance (given on that quarter's call) | Discl = disclosure for the quarter reported | blue = transcript-sourced hardcode | ↑/↓ = raised/lowered | SS = self-serve").font = font(italic=True, size=6, color="808080")
    r += 1
    ws.cell(r, 2, f"Generated {NOW}").font = font(italic=True, size=6, color="808080")
    FOOT = r

