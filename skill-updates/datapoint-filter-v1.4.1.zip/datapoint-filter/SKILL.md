---
name: datapoint-filter
description: "Bobby Ashkenazi's (SRS Investment Management) Datapoint Filter: the single shared standard for deciding which investment datapoints are kept, how they are worded, and how they are staged and auto-loaded to Supabase. It is the admission test, stored-evidence check, auto-load policy, compression standard and nine-field entry contract used by every extraction skill (tech-email-digest-new, semianalysis-digest, research-folder-digest, analyst-folder-extractor, datapoint-organizer, sellside-folder-digest, earnings-review, and any future one). Always read this skill before extracting, filtering, shortening, auditing, deduplicating or uploading datapoints, whether another skill sends you here or Bobby asks directly: \"filter these datapoints\", \"would you keep this\", \"audit my datapoints\", \"clean up these entries\", \"shorten these\", \"what passes the filter\", \"stage these for Supabase\", \"upload these to Supabase\", or pastes research and asks what matters."
---

# Datapoint Filter

## Run cost tally (applies to every run)

Keep a running token tally from the moment this skill loads until the final output is delivered. It is an **estimate** (the chat environment exposes no token meter), so always label it "est." and never present it as exact.

- **Tool calls (N):** count every tool call: MCP tools, Outlook/Notion/Slack, search/fetch, bash, file and skill reads.
- **In:** for every tool result and every file or skill read, add its approximate size in tokens: characters ÷ 4 for prose, characters ÷ 3 for tables, JSON or number-dense output. Use any size the tool reports (bytes, characters); otherwise estimate from length.
- **Out:** add the approximate size of everything written: tool inputs (page bodies, SQL, JSON, file contents) plus chat replies.
- Round to the nearest 1k (use 0.1k under 10k).
- **Report it** in the timestamp footer and as the last line of the chat reply: `Generated YYYY-MM-DD HH:MM ET · ~XXXk tokens est. (XXXk in / XXk out · N tool calls)`. If this skill otherwise has no footer, add this line at the end of its output.
- **Multi-turn runs** (a confirm or "continue" step): carry the tally forward and report the cumulative total.
- **Sub-step runs:** if this skill is being run inside another skill, do not print a separate line; the parent skill's tally includes this work.

**Version:** v1.4.1 (2026-11-05; adds the widely-repeated-view rule under Consolidation and provenance and the Callouts line under Output modes). v1.4.0 (2026-11-02; folds in the 2,000-row Supabase audit calibrations and the reorganized Notion reference, Parts 1–9: strict qualitative test, competitor moves and customer plans, analyst exceptions, materiality vs expectations, wording and dedup rules). Calling skills record this line, or the Notion master's date, in their Inputs section.

Prioritize signal over completeness. Keep a datapoint only if it materially changes Bobby's view, or meaningfully changes confidence in that view, of a company's growth, margins, competitive positioning, or shareholder returns. Explain exactly what changes and why.

This skill is the shared standard. A calling skill owns retrieval, its `source_type` value, its page layout and any source-specific overrides it names explicitly. Everything else about selecting, wording and staging a datapoint is here, so it is not repeated in each digest.

---

## Step 0 — Load the live standard (once per task, not once per entry)

Fetch the **OpenClaw Agent Feedback** Notion page (`33aa883333de817c853ef25feefea41d`) with `mcp__Notion__notion-fetch` (load it via `tool_search` first). If a calling skill already fetched it in this task, reuse that copy. The page is large: save it and grep for the toggles below rather than reading it whole.

1. **Master text: the toggle titled "🧩 SKILL: datapoint-filter — master text"** (top of Active Agents). Bobby edits the filter there; this file is the fallback copy. It is the skill's own text, not a calibration reference.
   - If the toggle has text, it governs. Compare it with this file. If they differ, follow the Notion text and report the drift in one line ("Notion master differs from skill v1.4.1: [what changed]") so Bobby can repackage the skill.
   - If the toggle is empty or missing, follow this file and say so.
2. **Calibration reference: the "Datapoint Filter" toggle under Global Feedback** (the one reference file; this skill toggle is separate). Read all nine sub-toggles (Part 1 — What a datapoint is … Part 9 — Change log), reorganized 2026-11-02. Ignore the "Archive — Datapoint Filter text before the 2026-11-02 reorganization" toggle except as history. Also read Cross-Agent Standards → "Evidence_text compression rules".
3. **"Supabase Database Reference File"**, sections 3, 7 and 8 only (entry object, JSON example, producer schema), when staging or uploading.

Read calibration examples as judgment examples, not verified current company facts or fixed ticker rules.

**If Notion cannot be fetched,** continue with this file and state that in the output. Never stop the calling workflow for it.

**Precedence:** Bobby's instruction in the current conversation > the calling skill's explicitly named overrides > the Notion master text > this file. Bobby's current calibration toggles override conflicting older examples. Note any conflict rather than silently picking one.

---

## Admission test

Require all four:

1. **Relevance:** Identify the company and affected investment assumption. Admit industry evidence when it changes an identifiable supply/demand or cost assumption for relevant companies.
2. **Consequence:** Explain a meaningful business or shareholder consequence relative to company size and the importance of the driver.
3. **Evidence:** Ensure the source supports the claim and attribution. Distinguish actuals, management targets, channel checks, forecasts, and inference.
4. **Increment:** Identify a new fact, meaningful revision, material baseline, correction, or independent confirmation that changes conviction.

**Qualitative evidence is held to a strict bar (Bobby, 2026-11-02).** A partner, channel, expert or management comment without a number passes only if it shows a concrete consequence: a guide cut, a delay or push-out, a correction to a monetization claim, a named deal won or lost, or a quantified change. Descriptive explanations ("E5 upgrades drove M365", "AI value articulated better") fail. Fewer, structural rows beat volume.

Return Keep or Remove only. Exclude unclear cases from the main thesis feed. Create no watchlist or speculative backlog; reconsider if stronger evidence later arrives. Set no quota, minimum per source, or target rejection rate. Zero qualifying datapoints is valid.

## Investment dimensions

Use exactly six categories: Growth, Margins, Competition, Shareholder return, TAM, Risks. Categorize pricing, demand outlook and product architecture within these; never propose them as additional categories. Choose the most directly affected assumption: weak demand is Growth, rising costs is Margins; not every negative is Risks.

| Dimension | Relevant assumptions |
| --- | --- |
| Growth | Revenue trajectory, demand durability, pricing, penetration, retention, bookings, backlog, deliverable capacity |
| Margins | Pricing power, costs, mix, utilization, operating leverage, capital intensity, sustainable unit economics |
| Competitive positioning | Share, differentiation, switching costs, substitution, distribution, technology relevance, bargaining power |
| Shareholder returns | Cash generation, returns on capital, allocation, dilution, leverage, financing, acquisitions/disposals, dividends, buybacks |

Connect risk to one of these outcomes; reject generic risk labels. Require no precise EPS/revenue estimate when the supported business mechanism is compelling. Admit meaningful customer qualification, adoption delays, actual monetization, cost actions, contract changes and corrections before their ultimate financial impact is measurable. Admit attributed forecasts that materially challenge a central assumption. Preserve uncertainty and opposing evidence.

## What passes (Notion Part 2)

Keep, subject to the admission test:

- **Orders and demand:** meaningful changes in bookings, orders, revenue, billings or significant customer wins that change a modeling assumption.
- **Framework flags** (LTAs, prepayments, deposits) as standalone rows: "underwrite the deposits, not the RPOs".
- **Assumptions behind guidance**, with their evidence base and whether management calls them conservative, realistic or optimistic (management's characterization, not ours).
- **Quantified plans**, the company's or a competitor's, even when only "planned" or "considering": capacity, investment or output figures (Mitsui considering 5,000t/month HVLP vs a 1,400t plan). Keep the label. New investor-day targets pass.
- **Revenue segmentation and concentration** Bobby isn't already tracking (ANET AI back-end +110% y/y, 43% of DC switching; CIEN direct cloud >50% of revenue).
- **Cost of capital and funding structure:** bond prices/yields, CDS, loan spreads/OID, cost of debt, posted LCs and collateral, tenant-funded capex, tenant interest-cost sharing, financing outcomes for capital-intensive borrowers. Map to Margins, Shareholder return or Risks.
- **Material capital allocation:** buybacks significant vs market cap, sizable ASRs, inaugural or special dividends, a huge capex investment or large capex step-up, completed material M&A. Not ordinary period FCF or FCF/share.
- **Customer milestones and corrections:** moving from sampling to qualification (keep "no orders yet"); customer push-outs that cause a guide cut; corrections to monetization claims.
- **A recap number that carries the reason it moved** (SG&A leverage offsetting a GM drop; a one-time payment adding +200bps; a pull-forward weakening the next quarter). Generic "favourable mix" does not qualify.
- **Specific capabilities or gaps** that affect competitive position or addressable workloads, even without a revenue figure.
- **Legal or regulatory items with established exposure:** affected programs, financial exposure, supply disruption, a substantive ruling, permitting pauses at named sites, customers pausing purchases.
- **GPU and compute pricing:** neocloud or hyperscaler GPU price increases, rental-rate moves, forward curves, residual values.

## What fails (Notion Part 3)

Exclude unless the admission test clearly passes:

- **Consensus restatements and routine recaps.** If Bobby could get the number from Visible Alpha or FactSet consensus, it is not new evidence, including beats/misses vs consensus or bogeys.
- **Ratings, price targets, stock moves, positioning, flows, whispers, buy-side bogeys** and explanations of stock reactions. Keep only the business evidence inside them.
- **Vague activity or advantages** without a consequential change; earnings numbers padded with product descriptions.
- **Small samples** (2–5 partners, 1 GSI, a few VARs) unless they show paid usage, a share change, a quantified rate or a monetization correction. Label the sample size when kept.
- **Intention surveys and proxies** (CIO or reseller surveys, web traffic, alt data): they are not spending.
- **Engagement or usage counts with no monetization.** If your own caveat says there is no monetization, cut the row. Usage or plan-structure changes without a price or revenue effect.
- **Static snapshots:** penetration %, generic mix, one-partner adoption %, static price comparisons.
- **Stale items:** repeated, "held since" or unchanged disclosures; targets first published months earlier; historical facts relayed late (a 2Q disclosure first appearing in an October note).
- **Unsigned talks** (M&A, credit guarantees, financing) and expected-but-unsigned commercial deals that tell little; uncommitted campuses, exploratory partnerships, personnel news.
- **Legal or procedural notices** without established exposure.
- **Product launches, specs, SDK/access updates, roadmaps and research demos** without orders or commercial consequence.
- **AI benchmarks** (scores, leaderboard ranks, evals, cost per task) and **model-maker token or API pricing** (per-token prices, token price indices, plan or allowance pricing). Bobby tracks these separately.
- **Funding or valuation announcements** without operating evidence; broad TAM or policy aspirations; mechanical scenario arithmetic.

## Analyst estimates (Notion Part 4)

An analyst's own forecasts, model outputs, estimate revisions and estimate-vs-consensus gaps are not datapoints; Bobby sees them in Visible Alpha. Keep the evidence behind them (channel checks, capacity locks, yields, qualification steps, order delays, supplier or customer comments, stated mix drivers) when it passes on its own, attributed to the firm. Two exceptions, each labelled "<Firm> est.":

1. **Scarce industry supply/demand series** Visible Alpha does not carry: CoWoS capacity, wafer starts, HBM bits, WFE, NAND/DRAM/HDD industry series, compute GW.
2. **Proprietary analysis:** numbers the analyst built from their own industry conversations, channel checks, teardowns or supply-chain builds that give unit economics, content, allocation or architecture figures Visible Alpha does not carry (Bernstein rack value and CLS share; TD Cowen TPU switch count). Company P&L forecasts, estimate revisions, PTs and estimate-vs-consensus still fail.

## Customers, suppliers, competitors and industry (Notion Part 5)

Evaluate whose growth, margins, position or returns change, not which company is named. Every read-through needs an explicit causal mechanism and material relevance; no automatic sector-wide read-throughs.

- **Significant customers:** a customer's quantified plan is an indirect number for the supplier; keep it (Musk's GPU deployment targets → CRDO when xAI is 10%+ of revenue). Label it the customer's target, not confirmed orders. Cut when the customer gives no number and no telling adjective.
- **Competitor moves are kept even when unquantified:** entry or exit, capacity or share targets, pricing actions, M&A, qualification wins or delays. File on the affected company; state it is the competitor's action and the mechanism.
- **Industry series:** capacity or pipeline additions and demand series (pipeline miles, industry capacity additions, US data-center construction spending, utility transmission capex), labelled as industry data with the mechanism.
- **Other read-throughs need a number** for the company or its customer; expert and roadmap read-throughs without one fail.

## Materiality (Notion Part 6)

- **One-off items** (order, deal, investment, capex step-up, buyback): material at roughly 3–5%+ of annual revenue, or significant vs market cap for capital returns.
- **Changes against expectations** (trend, guide, price, utilization, bookings, margin): judge direction first, then size. Wrong direction → keep even if small (guided growth but down 2%). Right direction → keep only if the size clearly changes the path (+15% vs a +5% guide); cut "+6% vs +5%" or "slightly better".
- **The expectation must be stated in the source or on record:** prior company guidance or commentary, the prior trend the source cites, or an explicit expectation in the note. Never our own assumption and never Visible Alpha consensus. With no stated expectation, apply the normal tests.

**Never overstate the evidence.** Do not infer company margin from customer API prices or experimental speedups. Do not treat ARR as recognized revenue, contract value as annual revenue, planned MW as operating capacity, or intended migration as realized churn. Never invent a baseline, consensus gap, contribution, date, confidence level, or holding.

## Consolidation and provenance

Treat one underlying event as one event. Link affected companies instead of multiplying generic signals. Preserve distinct supported company effects. Consolidate earnings details while preserving separate growth/margin implications. Attach useful detail, denials and corrections; never erase counterevidence.

**Relays are not corroboration.** Multiple relays of one original source are one event. Notes from the same firm built on the same checks (e.g. a Cleveland "Juice" email plus its company notes, or an initiation plus its Juice) are one source: attribute each fact to the item that states it most fully and never count them as confirming each other. Count a later item as confirmation only if its evidence is independent.

**Widely repeated views (Bobby, 2026-11-05).** Repetition is a signal of importance, not of evidence. When 3+ independent sources (different firms or writers, not relays of one origin) cite or debate the same view or number in the same window, admit it as one event even if it is one person's opinion or forecast, provided it carries a number or mechanism and passes Relevance and Consequence. This overrides the analyst-estimates and pure-opinion exclusions for that view only. Example: Brad Gerstner's "10-15GW of the ~43GW 2027 build may not come online" (All-In, 2026-11-04), repeated by TMTB, Morgan Stanley, UBS and others.

- Stage one row, attributed to the origin ("Brad Gerstner, All-In podcast"), with the fullest relay as `secondary_source`. Say in `evidence_text` that it is a forecast or opinion, not an actual.
- Never label it "single-source"; record the count and who repeated it ("cited by 5: TMTB, MS, UBS...") on the page.
- Repetition never raises `confidence`. That stays with the origin's credibility and evidence.
- Keep opposing estimates beside it (e.g. a bottom-up model that is lower) so the page shows the range.

**Row boundaries.** One coherent development per row. Split heterogeneous bundles (different drivers, signs or tickers); keep a homogeneous metric set from one observation together. The ticker is the company whose revenue, margins or position moves. A second-order read-through gets its own row on the affected company, with the causal mechanism stated in the evidence text.

**Dedup by company, not ticker.** Several companies sit under more than one `research_id` (known: Kioxia 80/193, GE Vernova 426/547, STMicro 372/552/592, Accenture 450/608; see Notion Part 8 for the current list). Check all of a company's IDs before calling a row new.

For duplicate audit rows, return Remove as a standalone entry and identify the retaining entry/event. Move the removed row's unique facts into the retaining row, keeping different scopes separate (China vs SE Asia) rather than merging them. If the retaining record was not inspected, label consolidation as proposed; do not claim its content is preserved. Label a historical material baseline as a baseline. Disclose when archive-wide novelty was not checked.

## Concise entries without information loss

Apply this standard to every new extracted/database entry and whenever asked to shorten existing entries. Read the compression toggles before rewrites and before the first database-writing batch.

- Lead with the material fact/change and its key numbers. Follow with the supported business consequence or essential caveat. Prefer one or two short sentences, usually 25–50 words; use more whenever needed to preserve important information. Set no hard word limit or required reduction percentage.
- Preserve every material number, unit, period, comparison/baseline, timing, scope, causal mechanism, attribution, uncertainty, condition, correction and opposing fact. Preserve distinctions such as actual versus target, ARR versus revenue, customer versus company savings, and example versus company-wide practice.
- Remove repetition, filler, lengthy introductions, redundant labels, generic implications and nonmaterial product/process detail. Do not erase material content merely because it was not the headline. Use familiar abbreviations; avoid ambiguous shorthand.
- Keep source URLs, full provenance and other structured metadata in their dedicated fields. Avoid repeating them in evidence text, but retain attribution needed to distinguish a claim/forecast from an actual result. If no suitable metadata field exists, retain important provenance inline; never discard it to meet the length preference.
- **Keep hedge words and attribution** ("expected", "targets", "potentially", "considering", "could", "mgmt", "<Firm> est."). Never turn a forecast into a fact, an expectation into a delivered timeline, or an analyst estimate into a channel check. Separate claims from outcomes: design win ≠ shipments; received prepayments ≠ prospective commitments; buyback authorization ≠ spend; target capacity ≠ operating capacity.
- **Don't change who or what drives an effect**, and don't merge separate claims into one causal claim.
- **Don't silently convert units or bases** (% vs percentage points; "+2–3x" vs "2–3x"; nm vs mm). Flag the ambiguity instead.
- **No interpretation the source didn't make, and no staging labels** ("Company disclosure.", "Analyst view…", "Unsourced check."). Provenance lives in the source fields; "<Firm> est." is the only inline source label needed.
- **Automated check before accepting rewrites:** for every rewritten row, list any number or hedge word (expected, targets, potentially, considering, could, may, mgmt, est., proposes, planned, unconfirmed, decelerated) present in the original but missing from the rewrite. Restore each one or note why it was deliberately cut (a failing part removed).
- Before accepting a rewrite, compare it against the complete original/source. Check all material facts, numbers and qualifications, and verify that the shortened version adds no unsupported certainty, inference or financial impact. If a shorter version loses meaning, retain the longer wording.

---

## Entry contract (Supabase staging)

Every staged row has exactly these nine fields and no others. The full field rules, enum values and a worked example are in **Appendix: Entry contract** at the end of this file; read it before staging the first row of a task.

`research_id`, `field_key`, `evidence_text`, `event_date`, `field_impact`, `primary_source`, `secondary_source`, `source_type`, `confidence`

The essentials, so nothing is missed even before the reference is read:

- **field_key** (schema keys, all skills): Growth → `growth_driver`, Margins → `margin_driver`, Competition → `competition`, Shareholder return → `shareholder_return`, TAM → `tam`, Risks → `risk`. No numbered keys, no plain-English categories, no `earnings` key.
- **field_impact:** `positive` / `negative` / `mixed` only (live producer schema). Direction of effect on the business, not on a long/short view. Intensity is display-only: 🟢🟢 and 🔴🔴 mark broad or structural changes on the page, but the row still stages `positive` or `negative`; 🔵 is `mixed`.
- **primary_source** is the underlying origin; **secondary_source** is the intermediary that delivered it. The person who forwarded or emailed it is never the primary source.
- **source_type** is set by the calling skill and describes the kind of origin, never the delivery channel: broker research received by email is `sell_side`, not `email`. Live values are listed in the reference below.
- **research_id:** a resolved integer `research.id`, or null. When null, add `ticker` and `company` beside the row (the only permitted extra fields) so the uploader can resolve it; null rows are blocked at upload. Never invent IDs.
- **secondary_source:** the intermediary, or null if none (a real null, never an empty string or the text "None"). In the database it keeps the full trail ("Name (Firm) email, YYYY-MM-DD, subject"); digest pages and callouts show the firm only.
- **source_type** follows the origin: management statements relayed by a broker are `company`; IDC, TrendForce and Census data are not `sell_side`.
- **confidence:** company disclosures `high`; channel checks and analyst figures `medium`; proxies and alt data `low`. Don't default to medium.
- **event_date:** first publication by the attributable source, not the relay date.
- No staging tags (`datapoint_class`, `quant/qual`, `derivation`, `sector`, etc.). Context goes in `evidence_text`.

---

## Output modes

**Extraction** (the default inside a digest): return only qualifying entries, each with:

- **What changed:** fact, revision, correction, material baseline, or meaningful confirmation.
- **Why it matters:** affected assumption and consequence.
- Company/ticker, dimension, source/link, event date distinct from insertion date, relevant numbers/units/period/baseline, attribution, uncertainty, opposing evidence, shared-event link when applicable, and the staged row.

State missing information. Report counts kept vs removed per input; detail rejected items only when asked for an audit. Apply admission before scoring. Keep credibility (`confidence`), direction (`field_impact`) and investment importance distinct. Never let repeated weak facts outweigh material events through entry count. A widely repeated view (see Consolidation and provenance) is still one row, but calling skills put it in Callouts ahead of single mentions and show its source count.

**Audit** (Bobby asks which existing entries should stay): retain every requested row.

Entry ID | Company | Original entry | Keep/Remove | Affected dimension | Reason

Preserve original text separately from analysis. Give an individual reason and duplicate destination. For large reviews, provide a filterable table/file with reconciled totals.

For large audits (2026-11-02 practice): group rows by company so duplicates and alias records sit together; mark each decision `clear` or `borderline`; write the final wording for kept rows in the same pass; flag data problems (wrong `source_type`, confidence, date, company mapping, staging labels, contradictions) in a separate column. When Bobby sends the file to a second reviewer, add reviewer columns (decision, reason, wording issue, agree?) with borderline rows first, then reconcile row by row: accept or decline each reversal with a stated reason. Audits stay review-only; deleting or rewriting stored rows needs Bobby's explicit approval of the exact ID list and a backup first.

**Shortening only:** preserve each entry's substantive content and identity. Do not silently filter it out, merge events, delete rows, reclassify it or change dates/scores/source fields. Offer removal/consolidation separately only if requested. For a preview, show Entry ID | Original entry | Shortened entry, keeping the original intact. Applying rewrites to stored rows requires an explicit request and follows the scoped update procedure in the Supabase reference.

---

## Notion inputs and Supabase uploads

Read the Supabase Database Reference File when reading a Notion output, checking stored evidence, or uploading. Use the verified default database recorded there; accept a user-specified replacement. Revalidate the live destination and schema before writes. Ask for the project link/reference only if the saved destination cannot be resolved or the intended destination is ambiguous.

When filtering a Notion output Bobby identifies, fetch it including relevant nested content and requested database/view results. Preserve page URLs and original source attribution. Inclusion in a Notion output does not establish quality or novelty; apply the same admission test.

Extraction runs of the skills named in the Auto-load policy below load qualifying rows automatically under that policy. Everything else defaults to review only: when Bobby explicitly asks to upload/save/add qualifying datapoints to Supabase, filter and deduplicate, then insert the qualifying new evidence without a second approval. A request to edit this skill is configuration authorization only, not permission to ingest research. Do not upload rejected entries. Do not modify Notion content, existing evidence, thesis definitions, scores, schema or jobs because an upload was requested. If the live column rejects a value (e.g. a new `source_type`), report the blocked rows; never substitute another value. Report inserted IDs and counts, duplicate skips, rejected counts and blocked/failed records, and verify persisted rows before claiming success.

## Auto-load policy (Bobby, 2026-10-27)

Bobby's standing instruction: datapoints that pass this filter in the extraction digests load to Supabase automatically, with no approval step. This is the explicit upload authorization for those runs.

**Scope.** Extraction runs of `research-folder-digest`, `tech-email-digest-new`, `semianalysis-digest`, `alphasense-digest`, `analyst-folder-extractor`, `sellside-folder-digest` and `earnings-review` (its call datapoints only; beats and misses vs consensus or bogeys fail admission as consensus restatements). Not `datapoint-organizer` (it skips the admission test), not audit or shortening modes, and not ad hoc filtering in chat; those stay review-only unless Bobby asks to upload. Bobby turns it off for a run with "stage only", "dry run" or "don't upload".

**Destination.** Supabase project `hftouzahniiwigcchvje` ("bashkenazi's Project"), table `public.research_evidence`, via `mcp__Supabase__execute_sql` (load with `tool_search` "supabase execute sql"). Verified 2026-10-27: nine producer columns plus database-generated `id` and `created_at`; `research_id` NOT NULL, FK to `research`; `field_impact` CHECK; enums `source_type_enum` and `confidence_enum` (`high`/`medium`/`low`). The other project ("Clawd Shared Memory", `wjpjpzdzpsauwjccxaec`) has no evidence tables; never write there. At the start of each load, confirm the table, the six `active_research_fields` keys and the `source_type_enum` values in one query; if they differ from this section, stage only and report the difference. If the Supabase tools are unavailable, stage only and say so.

**A. Stored-evidence check (before the increment test)**

Run once per task, after candidates are extracted and before admission is decided:

1. Resolve every ticker in the run to `research_id` with one query on `research_directory` (match ticker and confirm the company name; resolve aliases, and include every `research_id` the company sits under, e.g. Kioxia 80 and 193). Never infer or invent an ID.
2. Pull stored evidence for those IDs in one query, saved to a file and read per ticker. Heavily covered names carry ~100+ rows a month (NVDA, MU, AMD: ~1,570 rows in 120 days), so keep it compact:

```sql
select id, research_id, field_key, event_date, left(primary_source, 60) src, left(evidence_text, 160) ev
from (select e.*, row_number() over (partition by research_id order by event_date desc, id desc) rn
      from research_evidence e
      where research_id = any(array[<ids>]) and event_date >= current_date - 60) x
where rn <= 60 order by research_id, event_date desc;
```

For a candidate that may restate an older event, run one batched lookup over 180 days on its distinctive figures or terms (`evidence_text ilike any(array['%300k%', '%MI455%', ...])`, scoped to its `research_id`).
3. Apply it in the increment test. A candidate that restates a stored row's underlying event (reworded, or arriving through another relay) is Remove as a duplicate; note the stored ID. A meaningful revision, correction, distinct company effect or independent confirmation still passes; name the stored ID it updates in **What changed**.
4. State the check's scope (window, rows read, tickers unresolved) in the calling skill's Inputs section.

**B. Load gate**

Load a kept row only if all of these hold; otherwise **hold** it (staged on the page, not loaded) with the reason:

- It passed the stored-evidence check.
- It validates against the nine-field contract: exact keys, enum values, a real calendar date, non-empty `evidence_text` and `primary_source`, `secondary_source` null or non-empty.
- `research_id` is resolved (non-null) and the company matches.
- `source_type` is non-null and in the live enum.
- `confidence` is `high` or `medium`.
- It is not labeled as inference, and its direction is known.
- `event_date` is a publication or delivery date, not a scan-date fallback, and the row is not a historical fact relayed late.
- The rewrite passed the automated hedge-and-number check (no material qualifier or figure dropped).

Never change a row to get it through the gate: no substituted `source_type`, invented ID or upgraded confidence.

**C. Insert**

After the digest page is published, so a staging record exists:

- Re-check for exact repeats (same `research_id`, `event_date` and `evidence_text`) and skip them; this makes reruns of the same window safe.
- One multi-row `INSERT` into the nine columns (split at 100 rows), `RETURNING id, research_id, field_key, event_date, created_at`. Never send `id` or `created_at`. Quote text with dollar-quoting on a tag absent from the text (e.g. `$ev$...$ev$`); cast enums explicitly (`'sell_side'::source_type_enum`, `'high'::confidence_enum`).
- On a timeout or error, check for committed rows before any retry.
- Never UPDATE or DELETE stored rows, create `research` or company records, change schema or enums, or touch scores. Conflicts with stored rows are held and reported for Bobby.

**D. Verify and report**

- Read back the returned IDs and confirm `research_id`, `field_key`, `event_date`, `source_type` and `confidence`. Staging alone is not loading; never report a row as loaded without the read-back.
- Update the digest page: each loaded datapoint shows `SB #<id>`; each held one shows `Held: <reason>`. Add a "📤 Supabase load" block to the Inputs section: loaded count and ID range, held rows with reasons, duplicates skipped with the stored ID, failures.
- End the chat reply with: `Supabase: N loaded (IDs a–b) · H held · D duplicates skipped · F failed`.
- If the load fails entirely, the published page remains the staging record; say so plainly.

## Scope and execution

Use this as a judgment filter. Outside the Auto-load policy it is not automatic write authorization. Apply it in chat or within another requested extraction workflow, alongside the relevant source, PDF, database and artifact skills. Do not browse merely to embellish an audit; verify sources when requested or necessary for a factual conclusion. Distinguish stored claims from independently verified facts.

Keep verified, nonsecret destination identifiers in the Supabase reference; store no credentials or purported current portfolio. Default to evaluation without mutations. Write, consolidate, delete, change scores/schema, or modify scheduled jobs only within explicit user instructions. Do not request repeat permission for already authorized work. Never claim an existing job uses this filter unless its integration was actually updated and verified.

**Final check:** What should Bobby think differently about this company because of this datapoint? If unclear, exclude it.

---

## Appendix: Entry contract (Supabase staging)

The live definition is the "Supabase Database Reference File" toggle on the OpenClaw Agent Feedback page. This file is the working copy for staging. If the live schema differs, the live schema wins; report the difference.

**Example (format illustration only, not a stored fact)**

```json
{
  "research_id": null,
  "field_key": "growth_driver",
  "evidence_text": "MI455 unit expectations revised to 300k+ on channel checks; [baseline], [timing] and [condition] go here when the source gives them.",
  "field_impact": "positive",
  "event_date": "2026-05-06",
  "primary_source": "Cleveland Research channel checks",
  "secondary_source": "Chandler Converse (Cleveland Research) email, 2026-05-06, [subject]",
  "source_type": "independent_research",
  "confidence": "medium"
}
```

With `research_id` null, stage `"ticker": "AMD", "company": "Advanced Micro Devices"` beside the row.

When a destination renders code blocks badly (Notion shows them as one unreadable line), show the row as wrapped plain text; the fields and values do not change.

**Field rules**

| Field | Rule |
| --- | --- |
| `research_id` | Existing `research.id` for the company, resolved from the database. Null if not resolvable this session; then add `ticker` and `company` beside the row and list it as an unresolved mapping. The live schema requires an integer ≥ 1, so null rows are staging-only and are blocked at upload until resolved. Never invent IDs. |
| `field_key` | `growth_driver` / `margin_driver` / `competition` / `shareholder_return` / `tam` / `risk`. Most directly affected assumption. One key per row; split the row if two assumptions move for different reasons. |
| `evidence_text` | Number-first statement of what was said, per the compression standard. States whether it is an actual, management target, channel observation, analyst forecast, or inference. No interpretation the source did not make. |
| `field_impact` | `positive` / `negative` / `mixed`. Effect on the company's business or shareholder economics. The SQL column also accepts `very_positive`/`very_negative`, but the producer contract uses three values because some uploaders support only those. Double dots on the page are display intensity only. Hold an unknown direction for review; never force `mixed`. |
| `event_date` | YYYY-MM-DD the information was first published by the attributable source, never the period described or the forecast horizon, and never the insertion date. If only the delivery date is known, use it and label it as a fallback. |
| `primary_source` | The resolved origin: a company disclosure, a named supplier contact, IDC/TrendForce, the analyst's own channel checks or model. If no origin is cited, the analyst's own work (e.g. "Cleveland Research channel checks", "SemiAnalysis — article title"). One origin per row. |
| `secondary_source` | The intermediary that delivered it, specific enough to find again: "Analyst Name (Firm) email, YYYY-MM-DD, subject", or the article when the primary is a third party. null if the primary arrived directly; never an empty string (the schema rejects it). |
| `source_type` | Set by the calling skill: the kind of origin, never the delivery channel. Live schema values: `company`, `sell_side`, `independent_research`, `news`, `substack`, `twitter`, `reddit`, `evernote`, `fintool`, `rogo`, `email`, or null. Independent research publishers, including SemiAnalysis, are `independent_research`. If the column rejects a value, report the blocked rows; never substitute. |
| `confidence` | Evidence credibility only (directness, expertise, specificity, independence): `high` / `medium` / `low` / null. Separate from direction and importance. |

**Display conventions for digest pages**

- Header line: impact dot + **TICKER** | Category | confidence
- Dots (display only): 🟢🟢 broad/structural positive, 🟢 positive, 🔵 mixed, 🔴 negative, 🔴🔴 broad/structural negative
- Dates YYYY-MM-DD everywhere; bold every model-moving figure
