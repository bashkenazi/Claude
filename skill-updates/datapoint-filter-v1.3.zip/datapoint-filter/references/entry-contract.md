# Entry contract (Supabase staging)

The live definition is the "Supabase Database Reference File" toggle on the OpenClaw Agent Feedback page. This file is
the working copy for staging. If the live schema differs, the live schema wins; report the difference.

Live schema verified 2026-10-27 in project `hftouzahniiwigcchvje`, table `public.research_evidence`.

## Example (format illustration only, not a stored fact)

```json
{
  "research_id": null,
  "field_key": "growth_driver",
  "evidence_text": "MI455 unit expectations revised to 300k+ on channel checks; [baseline], [timing] and [condition] go here when the source gives them.",
  "field_impact": "positive",
  "event_date": "2026-05-06",
  "primary_source": "Cleveland Research channel checks",
  "secondary_source": "Chandler Converse (Cleveland Research) email, 2026-05-06, [subject]",
  "source_type": "independent_research",
  "confidence": "medium"
}
```

With `research_id` null, stage `"ticker": "AMD", "company": "Advanced Micro Devices"` beside the row. Null rows are
held at load.

When a destination renders code blocks badly (Notion shows them as one unreadable line), show the row as wrapped plain
text; the fields and values do not change.

## Field rules

| Field | Rule |
|---|---|
| `research_id` | Existing `research.id` for the company, resolved from `research_directory` (confirm ticker and company name). Null if not resolvable this session; then add `ticker` and `company` beside the row and list it as an unresolved mapping. The live column is NOT NULL (integer ≥ 1, FK to `research`), so null rows are staging-only and held at load. Never invent IDs. |
| `field_key` | `growth_driver` / `margin_driver` / `competition` / `shareholder_return` / `tam` / `risk`. Most directly affected assumption. One key per row; split the row if two assumptions move for different reasons. |
| `evidence_text` | Number-first statement of what was said, per the compression standard. States whether it is an actual, management target, channel observation, analyst forecast, or inference. No interpretation the source did not make. |
| `field_impact` | `positive` / `negative` / `mixed`. Effect on the company's business or shareholder economics. The SQL column also accepts `very_positive`/`very_negative`, but the producer contract uses three values. Double dots on the page are display intensity only. Hold an unknown direction for review; never force `mixed`. |
| `event_date` | YYYY-MM-DD the information was first published by the attributable source, never the period described, the forecast horizon or the insertion date. If only the delivery date is known, use it and label it as a fallback. A scan-date fallback is held at load. |
| `primary_source` | The resolved origin: a company disclosure, a named supplier contact, IDC/TrendForce, the analyst's own channel checks or model. If no origin is cited, the analyst's own work (e.g. "Cleveland Research channel checks", "SemiAnalysis — article title"). One origin per row. |
| `secondary_source` | The intermediary that delivered it, specific enough to find again: "Analyst Name (Firm) email, YYYY-MM-DD, subject", or the article when the primary is a third party. null if the primary arrived directly; never an empty string. |
| `source_type` | Set by the calling skill: the kind of origin, never the delivery channel. Live `source_type_enum`: `email`, `evernote`, `news`, `twitter`, `reddit`, `substack`, `fintool`, `rogo`, `company`, `sell_side`, `independent_research`. Independent research publishers, including SemiAnalysis, BlueFin, Cleveland and Edgewater, are `independent_research`. If SemiAnalysis or a broker only relays a company disclosure, the company is primary and `source_type` is `company`. If the column rejects a value, hold the row; never substitute. |
| `confidence` | Evidence credibility only (directness, expertise, specificity, independence): `high` / `medium` / `low` / null. Separate from direction and importance. `low` and null are held at load. |

No other fields in the insert object. `id` and `created_at` are database-generated; never send them.

## Display conventions for digest pages

- Header line: impact dot + **TICKER** | Category | confidence
- Dots (display only): 🟢🟢 broad/structural positive, 🟢 positive, 🔵 mixed, 🔴 negative, 🔴🔴 broad/structural negative
- After load: `SB #<id>` on each loaded row; `Held: <reason>` on each held row
- Dates YYYY-MM-DD everywhere; bold every model-moving figure
